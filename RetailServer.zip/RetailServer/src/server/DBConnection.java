package server;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static Connection connection;

    public static Connection getConnection() {

        try {
            if (connection == null) {

                connection = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/retail_ai",
                        "root",
                        "vaishvi2006"   
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return connection;
    }
}
