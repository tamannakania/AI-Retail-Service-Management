package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.*;

import common.ProductBean;
import common.RetailService;
import common.SalesBean;

public class RetailServiceImpl extends UnicastRemoteObject implements RetailService {

    Connection con;

    protected RetailServiceImpl() throws RemoteException {
        super();
        con = DBConnection.getConnection();
    }
   
   
    @Override
    public List<ProductBean> getLowStockProducts() throws RemoteException {

        List<ProductBean> lowStockList = new ArrayList<>();

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT * FROM products WHERE stock_quantity < 10"
            );

            while (rs.next()) {
                ProductBean p = new ProductBean();
                p.setProductId(rs.getInt("product_id"));
                p.setName(rs.getString("name"));
                p.setCostPrice(rs.getDouble("cost_price"));
                p.setSellingPrice(rs.getDouble("selling_price"));
                p.setStockQuantity(rs.getInt("stock_quantity"));

                lowStockList.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lowStockList;
    }
   
    @Override
    public void updateProduct(ProductBean product) throws RemoteException {

        try {

            PreparedStatement ps =
                    con.prepareStatement(
                            "UPDATE products SET name=?, cost_price=?, selling_price=?, stock_quantity=? WHERE product_id=?"
                    );

            ps.setString(1, product.getName());
            ps.setDouble(2, product.getCostPrice());
            ps.setDouble(3, product.getSellingPrice());
            ps.setInt(4, product.getStockQuantity());
            ps.setInt(5, product.getProductId());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================== FIX 1: HARD DELETE instead of soft status flag ==================

    @Override
    public void deleteProduct(int productId) throws RemoteException {

        try {
            // First delete any sales records referencing this product
            // (remove this block if you want to keep sales history — then use a FK-safe approach)
            PreparedStatement deleteSales = con.prepareStatement(
                    "DELETE FROM sales WHERE product_id = ?"
            );
            deleteSales.setInt(1, productId);
            deleteSales.executeUpdate();

            // Now delete the product itself
            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM products WHERE product_id = ?"
            );
            ps.setInt(1, productId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String login(String username, String password) throws RemoteException {

        try {

            PreparedStatement ps = con.prepareStatement(
                    "SELECT role FROM users WHERE username = ? AND password = ?"
            );

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString("role");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }


    // ================== FIX 2: ADD PRODUCT with duplicate name check ==================

    @Override
    public void addProduct(ProductBean product) throws RemoteException {

        try {
            // Check if a product with the same name already exists (case-insensitive)
            PreparedStatement checkPs = con.prepareStatement(
                    "SELECT COUNT(*) FROM products WHERE LOWER(name) = LOWER(?)"
            );
            checkPs.setString(1, product.getName());
            ResultSet checkRs = checkPs.executeQuery();

            if (checkRs.next() && checkRs.getInt(1) > 0) {
                // Product already exists — throw an exception so the client can show a prompt
                throw new RemoteException("DUPLICATE_PRODUCT: A product named \"" + product.getName() + "\" already exists.");
            }

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO products(name, cost_price, selling_price, stock_quantity) VALUES (?, ?, ?, ?)"
            );

            ps.setString(1, product.getName());
            ps.setDouble(2, product.getCostPrice());
            ps.setDouble(3, product.getSellingPrice());
            ps.setInt(4, product.getStockQuantity());

            ps.executeUpdate();

        } catch (RemoteException re) {
            // Re-throw so the client receives it
            throw re;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================== GET ALL PRODUCTS ==================

    @Override
    public List<ProductBean> getAllProducts() throws RemoteException {

        List<ProductBean> list = new ArrayList<>();

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM products");

            while (rs.next()) {

                ProductBean p = new ProductBean();
                p.setProductId(rs.getInt("product_id"));
                p.setName(rs.getString("name"));
                p.setCostPrice(rs.getDouble("cost_price"));
                p.setSellingPrice(rs.getDouble("selling_price"));
                p.setStockQuantity(rs.getInt("stock_quantity"));

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ================== ADD SALE + REDUCE STOCK ==================

    @Override
    public void addSale(SalesBean sale) throws RemoteException {

        try {

            // Insert Sale
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO sales(product_id, quantity, date, total_amount) VALUES (?, ?, ?, ?)"
            );

            ps.setInt(1, sale.getProductId());
            ps.setInt(2, sale.getQuantity());
            ps.setDate(3, java.sql.Date.valueOf(sale.getDate()));
            ps.setDouble(4, sale.getTotalAmount());

            ps.executeUpdate();

            // Reduce Stock
            PreparedStatement updateStock = con.prepareStatement(
                    "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?"
            );

            updateStock.setInt(1, sale.getQuantity());
            updateStock.setInt(2, sale.getProductId());

            updateStock.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================== AI SALES PREDICTION ==================

    @Override
    public Map<String, Double> getSalesPredictionInsights() throws RemoteException {

        Map<String, Double> result = new HashMap<>();
        List<Double> monthlySales = new ArrayList<>();

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT SUM(total_amount) as total " +
                    "FROM sales GROUP BY MONTH(date) ORDER BY MONTH(date)"
            );

            while (rs.next()) {
                monthlySales.add(rs.getDouble("total"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        if (monthlySales.size() == 0) {
            result.put("prediction", 0.0);
            result.put("growth", 0.0);
            return result;
        }

        double predicted;

        if (monthlySales.size() < 3) {

            double sum = 0;
            for (double val : monthlySales)
                sum += val;

            predicted = sum / monthlySales.size();

        } else {

            int size = monthlySales.size();
            double last1 = monthlySales.get(size - 1);
            double last2 = monthlySales.get(size - 2);
            double last3 = monthlySales.get(size - 3);

            predicted = (last1 + last2 + last3) / 3;
        }

        double lastMonth = monthlySales.get(monthlySales.size() - 1);
        double growthRate = ((predicted - lastMonth) / lastMonth) * 100;

        result.put("prediction", predicted);
        result.put("growth", growthRate);

        return result;
    }

    // ================== MONTHLY REVENUE ==================

    @Override
    public Map<String, Double> getMonthlyRevenue() throws RemoteException {

        Map<String, Double> revenueMap = new HashMap<>();

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT MONTH(date) as month, SUM(total_amount) as total " +
                    "FROM sales GROUP BY MONTH(date)"
            );

            while (rs.next()) {
                String month = "Month " + rs.getInt("month");
                double total = rs.getDouble("total");

                revenueMap.put(month, total);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return revenueMap;
    }

    // ================== TOP SELLING PRODUCTS ==================

    @Override
    public Map<String, Integer> getTopSellingProducts() throws RemoteException {

        Map<String, Integer> productMap = new HashMap<>();

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT p.name, SUM(s.quantity) as total_sold " +
                    "FROM sales s JOIN products p ON s.product_id = p.product_id " +
                    "GROUP BY p.name"
            );

            while (rs.next()) {
                String name = rs.getString("name");
                int total = rs.getInt("total_sold");

                productMap.put(name, total);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return productMap;
    }
}
