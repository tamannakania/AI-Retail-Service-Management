package server;

import common.RetailService;
import java.rmi.registry.LocateRegistry;
import java.rmi.Naming;

public class ServerMain {

    public static void main(String[] args) {

        try {

            LocateRegistry.createRegistry(1099);

            RetailService service = new RetailServiceImpl();

            Naming.rebind("RetailService", service);

            System.out.println("Retail RMI Server Started...");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
