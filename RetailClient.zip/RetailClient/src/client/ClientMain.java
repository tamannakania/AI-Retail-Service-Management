package client;

import common.ProductBean;
import common.RetailService;
import common.SalesBean;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.animation.*;
import javafx.util.Duration;

import java.rmi.Naming;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class ClientMain extends Application {

    private RetailService service;
    private TableView<ProductBean> table = new TableView<>();
    private StackPane contentArea = new StackPane();

    private StackPane aiPanelOverlay = null;

    // ─── Design tokens ────────────────────────────────────────────────────────
    private static final String BG_DEEP        = "#0B0E1A";
    private static final String BG_CARD        = "#131929";
    private static final String BG_SURFACE     = "#1A2135";
    private static final String BG_ELEVATED    = "#1F2C42";
    private static final String ACCENT_BLUE    = "#4F8EF7";
    private static final String ACCENT_CYAN    = "#00D4FF";
    private static final String ACCENT_GREEN   = "#00E5A0";
    private static final String ACCENT_AMBER   = "#FFB830";
    private static final String ACCENT_RED     = "#FF4D6D";
    private static final String ACCENT_PURPLE  = "#A78BFA";
    private static final String TEXT_PRIMARY   = "#E8EDF8";
    private static final String TEXT_SECONDARY = "#7A8BAF";
    private static final String TEXT_MUTED     = "#3D4F6E";
    private static final String BORDER         = "#1E2D47";

    private static final String FIELD_STYLE =
            "-fx-background-color:" + BG_ELEVATED + ";" +
            "-fx-background-radius:10;" +
            "-fx-text-fill:" + TEXT_PRIMARY + ";" +
            "-fx-prompt-text-fill:" + TEXT_SECONDARY + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:10;" +
            "-fx-border-width:1.5;" +
            "-fx-padding:10 14;" +
            "-fx-font-size:13px;";

    private static final String FIELD_FOCUS_STYLE =
            "-fx-background-color:" + BG_ELEVATED + ";" +
            "-fx-background-radius:10;" +
            "-fx-text-fill:" + TEXT_PRIMARY + ";" +
            "-fx-prompt-text-fill:" + TEXT_SECONDARY + ";" +
            "-fx-border-color:" + ACCENT_BLUE + ";" +
            "-fx-border-radius:10;" +
            "-fx-border-width:1.5;" +
            "-fx-padding:10 14;" +
            "-fx-font-size:13px;";

    @Override
    public void start(Stage stage) {
        try {
            service = (RetailService) Naming.lookup("rmi://localhost/RetailService");
        } catch (Exception e) {
            e.printStackTrace();
        }
        showLoginScreen(stage);
    }

    private void loadProducts() {
        try {
            table.getItems().clear();
            table.getItems().addAll(service.getAllProducts());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clearFields(TextField... fields) {
        for (TextField f : fields) f.clear();
    }

    // ─── Shared Helpers ───────────────────────────────────────────────────────

    private TextField styledField(String prompt) {
        TextField f = new TextField();
        f.setPromptText(prompt);
        f.setStyle(FIELD_STYLE);
        f.focusedProperty().addListener((o, ov, nv) ->
                f.setStyle(nv ? FIELD_FOCUS_STYLE : FIELD_STYLE));
        return f;
    }

    private PasswordField styledPass(String prompt) {
        PasswordField f = new PasswordField();
        f.setPromptText(prompt);
        f.setStyle(FIELD_STYLE);
        f.focusedProperty().addListener((o, ov, nv) ->
                f.setStyle(nv ? FIELD_FOCUS_STYLE : FIELD_STYLE));
        return f;
    }

    private Button primaryBtn(String text) {
        Button b = new Button(text);
        b.setStyle(
            "-fx-background-color:linear-gradient(to right," + ACCENT_BLUE + "," + ACCENT_CYAN + ");" +
            "-fx-text-fill:white;" +
            "-fx-background-radius:10;" +
            "-fx-font-size:13px;" +
            "-fx-font-weight:bold;" +
            "-fx-padding:10 22;" +
            "-fx-cursor:hand;"
        );
        b.setOnMouseEntered(e -> b.setOpacity(0.88));
        b.setOnMouseExited(e -> b.setOpacity(1.0));
        b.setEffect(new DropShadow(12, Color.web(ACCENT_BLUE, 0.55)));
        return b;
    }

    private Button secondaryBtn(String text) {
        Button b = new Button(text);
        String base =
            "-fx-background-color:" + BG_ELEVATED + ";" +
            "-fx-text-fill:" + TEXT_PRIMARY + ";" +
            "-fx-background-radius:10;" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:10;" +
            "-fx-border-width:1.5;" +
            "-fx-font-size:13px;" +
            "-fx-padding:9 18;" +
            "-fx-cursor:hand;";
        String hover =
            "-fx-background-color:" + BG_SURFACE + ";" +
            "-fx-text-fill:" + ACCENT_CYAN + ";" +
            "-fx-background-radius:10;" +
            "-fx-border-color:" + ACCENT_BLUE + ";" +
            "-fx-border-radius:10;" +
            "-fx-border-width:1.5;" +
            "-fx-font-size:13px;" +
            "-fx-padding:9 18;" +
            "-fx-cursor:hand;";
        b.setStyle(base);
        b.setOnMouseEntered(e -> b.setStyle(hover));
        b.setOnMouseExited(e -> b.setStyle(base));
        return b;
    }

    private Button dangerBtn(String text) {
        Button b = new Button(text);
        b.setStyle(
            "-fx-background-color:" + BG_ELEVATED + ";" +
            "-fx-text-fill:" + ACCENT_RED + ";" +
            "-fx-background-radius:10;" +
            "-fx-border-color:" + ACCENT_RED + ";" +
            "-fx-border-radius:10;" +
            "-fx-border-width:1.5;" +
            "-fx-font-size:13px;" +
            "-fx-padding:9 18;" +
            "-fx-cursor:hand;"
        );
        b.setOnMouseEntered(e -> b.setOpacity(0.8));
        b.setOnMouseExited(e -> b.setOpacity(1.0));
        return b;
    }

    private Label sectionLabel(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:11px;-fx-font-weight:bold;");
        return l;
    }

    private Label headingLabel(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:20px;-fx-font-weight:bold;");
        return l;
    }

    private Label makeSub(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:13px;");
        return l;
    }

    private void applyTableStyle() {
        table.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:12;" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:12;" +
            "-fx-border-width:1.5;" +
            "-fx-table-cell-border-color:transparent;" +
            "-fx-text-fill:" + TEXT_PRIMARY + ";"
        );
        table.setFixedCellSize(42);
    }

    private VBox card(javafx.scene.Node... children) {
        VBox box = new VBox(14, children);
        box.setPadding(new Insets(22));
        box.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:16;" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:16;" +
            "-fx-border-width:1;"
        );
        box.setEffect(new DropShadow(20, Color.web("#000000", 0.45)));
        return box;
    }

    private void showAlert(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setContentText(msg);
        a.show();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── LOGIN (MODERNIZED ENTERPRISE SPLIT-PANEL) ───────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    private void showLoginScreen(Stage stage) {
        // ── Root: full-width HBox split-panel ────────────────────────────────
        HBox root = new HBox();
        root.setPrefSize(1100, 680);

        // ════════════════════════════════════════════════
        // LEFT BRAND PANEL
        // ════════════════════════════════════════════════
        StackPane leftPanel = new StackPane();
        leftPanel.setPrefWidth(520);
        leftPanel.setMinWidth(520);
        leftPanel.setStyle("-fx-background-color:" + BG_DEEP + ";");

        // ── Animated grid background ─────────────────────
        Pane gridCanvas = new Pane();
        gridCanvas.setStyle("-fx-background-color:transparent;");
        int GRID_COLS = 14, GRID_ROWS = 18;
        double cellW = 520.0 / GRID_COLS, cellH = 680.0 / GRID_ROWS;
        List<Line> gridLines = new ArrayList<>();
        // Vertical lines
        for (int c = 0; c <= GRID_COLS; c++) {
            Line vl = new Line(c * cellW, 0, c * cellW, 680);
            vl.setStroke(Color.web(ACCENT_BLUE, 0.07));
            vl.setStrokeWidth(1);
            gridCanvas.getChildren().add(vl);
            gridLines.add(vl);
        }
        // Horizontal lines
        for (int r = 0; r <= GRID_ROWS; r++) {
            Line hl = new Line(0, r * cellH, 520, r * cellH);
            hl.setStroke(Color.web(ACCENT_BLUE, 0.07));
            hl.setStrokeWidth(1);
            gridCanvas.getChildren().add(hl);
            gridLines.add(hl);
        }

        // ── Glowing diagonal accent lines ────────────────
        Pane accentLines = new Pane();
        accentLines.setStyle("-fx-background-color:transparent;");
        String[] lineColors = {ACCENT_BLUE, ACCENT_CYAN, ACCENT_PURPLE};
        double[][] lineDefs = {{-40, 680, 300, 0}, {80, 680, 560, 50}, {-100, 500, 200, 0}};
        for (int i = 0; i < lineDefs.length; i++) {
            Line dl = new Line(lineDefs[i][0], lineDefs[i][1], lineDefs[i][2], lineDefs[i][3]);
            dl.setStroke(Color.web(lineColors[i % lineColors.length], 0.12));
            dl.setStrokeWidth(1.5);
            accentLines.getChildren().add(dl);
        }

        // ── Ambient glow orbs ─────────────────────────────
        Pane orbPane = new Pane();
        orbPane.setStyle("-fx-background-color:transparent;");

        Circle orb1 = new Circle(200, Color.web(ACCENT_BLUE, 0.08));
        orb1.setEffect(new GaussianBlur(90));
        orb1.setTranslateX(60); orb1.setTranslateY(180);

        Circle orb2 = new Circle(140, Color.web(ACCENT_CYAN, 0.06));
        orb2.setEffect(new GaussianBlur(70));
        orb2.setTranslateX(380); orb2.setTranslateY(480);

        Circle orb3 = new Circle(110, Color.web(ACCENT_PURPLE, 0.07));
        orb3.setEffect(new GaussianBlur(60));
        orb3.setTranslateX(440); orb3.setTranslateY(100);

        orbPane.getChildren().addAll(orb1, orb2, orb3);

        // Orb breathing animation
        for (Circle orb : new Circle[]{orb1, orb2, orb3}) {
            ScaleTransition st = new ScaleTransition(Duration.millis(3000 + Math.random() * 2000), orb);
            st.setFromX(0.85); st.setToX(1.2);
            st.setFromY(0.85); st.setToY(1.2);
            st.setAutoReverse(true); st.setCycleCount(Animation.INDEFINITE);
            st.play();
        }

        // ── Floating data particle nodes ──────────────────
        Pane particlePane = new Pane();
        particlePane.setStyle("-fx-background-color:transparent;");
        String[] particleLabels = {"₹ 2.4M", "↑ 12.5%", "847 SKUs", "99.9%", "₹ 18K", "23 Alerts", "LIVE"};
        String[] particleColors = {ACCENT_CYAN, ACCENT_GREEN, ACCENT_BLUE, ACCENT_GREEN, ACCENT_AMBER, ACCENT_RED, ACCENT_CYAN};
        double[][] particlePos = {{380, 140}, {60, 300}, {420, 380}, {140, 500}, {310, 560}, {80, 80}, {440, 240}};
        for (int i = 0; i < particleLabels.length; i++) {
            VBox particle = buildFloatingDataNode(particleLabels[i], particleColors[i]);
            particle.setTranslateX(particlePos[i][0]);
            particle.setTranslateY(particlePos[i][1]);
            particlePane.getChildren().add(particle);
            // Floating animation
            TranslateTransition float1 = new TranslateTransition(Duration.millis(2500 + i * 400), particle);
            float1.setByY(-10 - i * 2); float1.setAutoReverse(true);
            float1.setCycleCount(Animation.INDEFINITE); float1.play();
            // Fade-in stagger
            particle.setOpacity(0);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(600), particle);
            fadeIn.setToValue(0.85); fadeIn.setDelay(Duration.millis(800 + i * 180)); fadeIn.play();
        }

        // ── Brand content ─────────────────────────────────
        VBox brandContent = new VBox(0);
        brandContent.setAlignment(Pos.CENTER_LEFT);
        brandContent.setPadding(new Insets(0, 50, 0, 52));
        brandContent.setMaxWidth(420);
        StackPane.setAlignment(brandContent, Pos.CENTER_LEFT);

        // Logo mark
        StackPane logoMark = new StackPane();
        Circle logoBg = new Circle(28, Color.web(ACCENT_BLUE, 0.15));
        logoBg.setEffect(new DropShadow(18, Color.web(ACCENT_BLUE, 0.6)));
        logoBg.setStroke(Color.web(ACCENT_BLUE, 0.5));
        logoBg.setStrokeWidth(1.5);
        Label logoIcon = new Label("⬡");
        logoIcon.setStyle("-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:24px;");
        logoMark.getChildren().addAll(logoBg, logoIcon);
        logoMark.setMaxWidth(56); logoMark.setMaxHeight(56);

        // Version pill
        Label versionPill = new Label("  ENTERPRISE  v4.2  ");
        versionPill.setStyle(
            "-fx-text-fill:" + ACCENT_CYAN + ";" +
            "-fx-font-size:9px;-fx-font-weight:bold;-fx-letter-spacing:2;" +
            "-fx-background-color:" + ACCENT_CYAN + "15;" +
            "-fx-background-radius:20;-fx-border-color:" + ACCENT_CYAN + "44;" +
            "-fx-border-radius:20;-fx-border-width:1;-fx-padding:4 10;"
        );

        HBox logoRow = new HBox(14, logoMark, versionPill);
        logoRow.setAlignment(Pos.CENTER_LEFT);

        // Main brand headline
        Label headline1 = new Label("Retail");
        headline1.setStyle(
            "-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:52px;-fx-font-weight:bold;"
        );
        Label headline2 = new Label("Intelligence");
        headline2.setStyle(
            "-fx-text-fill:transparent;" +
            "-fx-font-size:52px;-fx-font-weight:bold;" +
            "-fx-background-color:linear-gradient(to right," + ACCENT_BLUE + "," + ACCENT_CYAN + ");" +
            "-fx-background-radius:0;" +
            "-fx-border-color:transparent;"
        );
        // JavaFX doesn't support text gradient fill natively, use a Label with colored text
        // Approximate with colored text
        headline2.setStyle(
            "-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:52px;-fx-font-weight:bold;"
        );
        Label headline3 = new Label("Platform");
        headline3.setStyle(
            "-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:52px;-fx-font-weight:bold;-fx-opacity:0.6;"
        );
        VBox headlines = new VBox(-8, headline1, headline2, headline3);

        Label tagline = new Label("Unified ERP · Real-time Analytics · AI-Powered Insights");
        tagline.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:12px;-fx-letter-spacing:0.5;");
        tagline.setWrapText(true);

        // ── Horizontal metric strip ────────────────────────
        VBox metricStrip = buildLoginMetricStrip();

        // ── Feature bullets ───────────────────────────────
        VBox featureBullets = buildLoginFeatureBullets();

        // ── Bottom "trusted by" bar ───────────────────────
        Label trustedLbl = new Label("TRUSTED ENTERPRISE PLATFORM");
        trustedLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:9px;-fx-font-weight:bold;-fx-letter-spacing:1.5;");

        HBox certBadges = new HBox(14);
        certBadges.setAlignment(Pos.CENTER_LEFT);
        for (String badge : new String[]{"ISO 27001", "SOC 2", "GDPR", "99.9% SLA"}) {
            Label b = new Label(badge);
            b.setStyle(
                "-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;" +
                "-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:6;" +
                "-fx-border-color:" + BORDER + ";-fx-border-radius:6;-fx-border-width:1;" +
                "-fx-padding:4 10;"
            );
            certBadges.getChildren().add(b);
        }
        VBox trustBar = new VBox(8, trustedLbl, certBadges);

        // Assemble brand content with spacing
        Region spacer1 = new Region(); spacer1.setPrefHeight(24);
        Region spacer2 = new Region(); spacer2.setPrefHeight(20);
        Region spacer3 = new Region(); spacer3.setPrefHeight(24);
        Region spacer4 = new Region(); spacer4.setPrefHeight(28);
        Region spacer5 = new Region(); spacer5.setPrefHeight(28);

        brandContent.getChildren().addAll(
            logoRow, spacer1, headlines, spacer2, tagline,
            spacer3, metricStrip, spacer4, featureBullets,
            spacer5, trustBar
        );

        // ── Divider line on right edge of left panel ──────
        Region divider = new Region();
        divider.setPrefWidth(1);
        divider.setPrefHeight(680);
        divider.setStyle(
            "-fx-background-color:linear-gradient(to bottom," +
            "transparent," + ACCENT_BLUE + "44, " + ACCENT_CYAN + "55," +
            ACCENT_BLUE + "44,transparent);"
        );
        StackPane.setAlignment(divider, Pos.CENTER_RIGHT);

        leftPanel.getChildren().addAll(gridCanvas, accentLines, orbPane, particlePane, brandContent, divider);

        // ════════════════════════════════════════════════
        // RIGHT LOGIN PANEL
        // ════════════════════════════════════════════════
        StackPane rightPanel = new StackPane();
        HBox.setHgrow(rightPanel, Priority.ALWAYS);
        rightPanel.setStyle("-fx-background-color:#0D1220;");

        // Subtle right-panel background texture
        Pane rightBg = new Pane();
        Circle rightOrb1 = new Circle(160, Color.web(ACCENT_BLUE, 0.04));
        rightOrb1.setEffect(new GaussianBlur(80));
        rightOrb1.setTranslateX(400); rightOrb1.setTranslateY(80);
        Circle rightOrb2 = new Circle(120, Color.web(ACCENT_CYAN, 0.035));
        rightOrb2.setEffect(new GaussianBlur(65));
        rightOrb2.setTranslateX(60); rightOrb2.setTranslateY(560);
        rightBg.getChildren().addAll(rightOrb1, rightOrb2);

        // ── Login form card ───────────────────────────────
        VBox loginCard = new VBox(0);
        loginCard.setMaxWidth(400);
        loginCard.setPrefWidth(400);
        loginCard.setPadding(new Insets(44, 44, 44, 44));
        loginCard.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:24;" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:24;" +
            "-fx-border-width:1;"
        );
        loginCard.setEffect(new DropShadow(50, Color.web("#000000", 0.65)));

        // Top accent bar on card
        Region cardAccent = new Region();
        cardAccent.setPrefHeight(3);
        cardAccent.setStyle(
            "-fx-background-color:linear-gradient(to right," + ACCENT_BLUE + "," + ACCENT_CYAN + "," + ACCENT_PURPLE + ");" +
            "-fx-background-radius:24 24 0 0;"
        );

        // Card inner content
        VBox cardInner = new VBox(22);
        cardInner.setPadding(new Insets(32, 0, 0, 0));

        // Welcome header
        Label welcomeLbl = new Label("Welcome back");
        welcomeLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:13px;");
        Label signInLbl = new Label("Sign in to your account");
        signInLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:22px;-fx-font-weight:bold;");
        VBox welcomeBlock = new VBox(4, welcomeLbl, signInLbl);

        // Input fields with labels
        VBox userBlock = new VBox(8);
        Label userLabel = new Label("USERNAME");
        userLabel.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;-fx-letter-spacing:1;");
        TextField user = styledField("Enter your username");
        user.setPrefWidth(Double.MAX_VALUE);
        // User icon prefix simulation via prompt
        userBlock.getChildren().addAll(userLabel, user);

        VBox passBlock = new VBox(8);
        Label passLabel = new Label("PASSWORD");
        passLabel.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;-fx-letter-spacing:1;");
        PasswordField pass = styledPass("Enter your password");
        pass.setPrefWidth(Double.MAX_VALUE);
        passBlock.getChildren().addAll(passLabel, pass);

        // Remember me + forgot password row
        CheckBox rememberBox = new CheckBox("Remember me");
        rememberBox.setStyle(
            "-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;" +
            "-fx-cursor:hand;"
        );
        Region remSpacer = new Region(); HBox.setHgrow(remSpacer, Priority.ALWAYS);
        Label forgotLbl = new Label("Forgot password?");
        forgotLbl.setStyle("-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:12px;-fx-cursor:hand;");
        forgotLbl.setOnMouseEntered(e -> forgotLbl.setStyle("-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:12px;-fx-cursor:hand;"));
        forgotLbl.setOnMouseExited(e  -> forgotLbl.setStyle("-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:12px;-fx-cursor:hand;"));
        HBox rememberRow = new HBox(rememberBox, remSpacer, forgotLbl);
        rememberRow.setAlignment(Pos.CENTER_LEFT);

        // Sign in button
        Button loginBtn = new Button("Sign In  →");
        loginBtn.setPrefWidth(Double.MAX_VALUE);
        loginBtn.setPrefHeight(48);
        loginBtn.setStyle(
            "-fx-background-color:linear-gradient(to right," + ACCENT_BLUE + " 0%," + ACCENT_CYAN + " 100%);" +
            "-fx-text-fill:white;-fx-font-size:14px;-fx-font-weight:bold;" +
            "-fx-background-radius:12;-fx-cursor:hand;" +
            "-fx-effect:dropshadow(gaussian," + ACCENT_BLUE + "88,18,0.4,0,4);"
        );
        loginBtn.setOnMouseEntered(e -> {
            loginBtn.setStyle(
                "-fx-background-color:linear-gradient(to right," + ACCENT_CYAN + " 0%," + ACCENT_BLUE + " 100%);" +
                "-fx-text-fill:white;-fx-font-size:14px;-fx-font-weight:bold;" +
                "-fx-background-radius:12;-fx-cursor:hand;" +
                "-fx-effect:dropshadow(gaussian," + ACCENT_CYAN + "99,22,0.5,0,6);"
            );
        });
        loginBtn.setOnMouseExited(e -> {
            loginBtn.setStyle(
                "-fx-background-color:linear-gradient(to right," + ACCENT_BLUE + " 0%," + ACCENT_CYAN + " 100%);" +
                "-fx-text-fill:white;-fx-font-size:14px;-fx-font-weight:bold;" +
                "-fx-background-radius:12;-fx-cursor:hand;" +
                "-fx-effect:dropshadow(gaussian," + ACCENT_BLUE + "88,18,0.4,0,4);"
            );
        });

        // Status message
        Label statusLabel = new Label();
        statusLabel.setWrapText(true);
        statusLabel.setMaxWidth(Double.MAX_VALUE);
        statusLabel.setVisible(false);
        statusLabel.setStyle(
            "-fx-text-fill:" + ACCENT_RED + ";-fx-font-size:12px;" +
            "-fx-background-color:" + ACCENT_RED + "11;-fx-background-radius:8;" +
            "-fx-border-color:" + ACCENT_RED + "44;-fx-border-radius:8;-fx-border-width:1;" +
            "-fx-padding:10 14;"
        );

        // ── Loading progress bar (animated) ──────────────
        StackPane loginProgress = new StackPane();
        loginProgress.setVisible(false);
        loginProgress.setPrefHeight(3);
        Region progressBg = new Region();
        progressBg.setPrefHeight(3);
        progressBg.setMaxWidth(Double.MAX_VALUE);
        progressBg.setStyle("-fx-background-color:" + BORDER + ";-fx-background-radius:2;");
        Region progressFill = new Region();
        progressFill.setPrefHeight(3);
        progressFill.setStyle("-fx-background-color:linear-gradient(to right," + ACCENT_BLUE + "," + ACCENT_CYAN + ");-fx-background-radius:2;");
        loginProgress.getChildren().addAll(progressBg, progressFill);
        StackPane.setAlignment(progressFill, Pos.CENTER_LEFT);

        // ── Security badge row ────────────────────────────
        Label lockIcon = new Label("🔒");
        lockIcon.setStyle("-fx-font-size:11px;");
        Label secureLabel = new Label("256-bit SSL · End-to-end encrypted · Zero-trust security");
        secureLabel.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;");
        HBox secureRow = new HBox(6, lockIcon, secureLabel);
        secureRow.setAlignment(Pos.CENTER);
        secureRow.setPadding(new Insets(6, 0, 0, 0));

        // Separator
        Separator formSep = new Separator();
        formSep.setStyle("-fx-background-color:" + BORDER + ";");

        // ── System status mini-indicator ──────────────────
        Circle statusDot = new Circle(5, Color.web(ACCENT_GREEN));
        FadeTransition dotPulse = new FadeTransition(Duration.millis(1000), statusDot);
        dotPulse.setFromValue(0.4); dotPulse.setToValue(1.0);
        dotPulse.setAutoReverse(true); dotPulse.setCycleCount(Animation.INDEFINITE); dotPulse.play();

        Label statusDotLbl = new Label("All systems operational");
        statusDotLbl.setStyle("-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:11px;");
        Region dotSpacer = new Region(); HBox.setHgrow(dotSpacer, Priority.ALWAYS);

        // Live clock
        Label loginClock = new Label();
        loginClock.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:11px;");
        Timeline loginClkTl = new Timeline(new KeyFrame(Duration.seconds(1),
            e -> loginClock.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")))));
        loginClkTl.setCycleCount(Timeline.INDEFINITE); loginClkTl.play();

        HBox sysStatusRow = new HBox(8, statusDot, statusDotLbl, dotSpacer, loginClock);
        sysStatusRow.setAlignment(Pos.CENTER_LEFT);
        sysStatusRow.setPadding(new Insets(10, 14, 10, 14));
        sysStatusRow.setStyle(
            "-fx-background-color:" + BG_ELEVATED + ";" +
            "-fx-background-radius:10;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:10;-fx-border-width:1;"
        );

        // Assemble card inner
        cardInner.getChildren().addAll(
            welcomeBlock,
            userBlock,
            passBlock,
            rememberRow,
            loginProgress,
            loginBtn,
            statusLabel,
            formSep,
            sysStatusRow,
            secureRow
        );

        // Wrap accent + inner in card
        loginCard.getChildren().addAll(cardAccent, cardInner);

        // ── Bottom copyright ──────────────────────────────
        Label copyright = new Label("© 2025 Retail AI Enterprise Platform · All rights reserved");
        copyright.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;");

        VBox rightContent = new VBox(20, loginCard, copyright);
        rightContent.setAlignment(Pos.CENTER);
        rightContent.setMaxWidth(480);

        rightPanel.getChildren().addAll(rightBg, rightContent);

        // ── Login action ──────────────────────────────────
        loginBtn.setOnAction(e -> {
            statusLabel.setVisible(false);
            // Animated progress bar
            loginProgress.setVisible(true);
            progressFill.setPrefWidth(0);
            Timeline progTl = new Timeline(
                new KeyFrame(Duration.millis(0),   new KeyValue(progressFill.prefWidthProperty(), 0)),
                new KeyFrame(Duration.millis(400), new KeyValue(progressFill.prefWidthProperty(), 200, Interpolator.EASE_BOTH))
            );
            progTl.play();
            loginBtn.setDisable(true);
            loginBtn.setText("Authenticating...");

            PauseTransition authDelay = new PauseTransition(Duration.millis(420));
            authDelay.setOnFinished(ev -> {
                try {
                    String role = service.login(user.getText(), pass.getText());
                    if (role == null) {
                        loginProgress.setVisible(false);
                        loginBtn.setDisable(false);
                        loginBtn.setText("Sign In  →");
                        statusLabel.setText("⚠  Invalid credentials. Please check your username and password.");
                        statusLabel.setVisible(true);
                        // Shake animation
                        TranslateTransition shake = new TranslateTransition(Duration.millis(55), loginCard);
                        shake.setByX(9); shake.setAutoReverse(true); shake.setCycleCount(6); shake.play();
                        // Highlight fields
                        user.setStyle(FIELD_FOCUS_STYLE.replace(ACCENT_BLUE, ACCENT_RED));
                        pass.setStyle(FIELD_FOCUS_STYLE.replace(ACCENT_BLUE, ACCENT_RED));
                        PauseTransition resetFields = new PauseTransition(Duration.seconds(2));
                        resetFields.setOnFinished(ev2 -> {
                            user.setStyle(FIELD_STYLE);
                            pass.setStyle(FIELD_STYLE);
                        });
                        resetFields.play();
                    } else {
                        // Success: full progress + slide transition
                        Timeline progDone = new Timeline(
                            new KeyFrame(Duration.millis(0),   new KeyValue(progressFill.prefWidthProperty(), 200)),
                            new KeyFrame(Duration.millis(280), new KeyValue(progressFill.prefWidthProperty(), loginCard.getWidth(), Interpolator.EASE_BOTH))
                        );
                        progDone.setOnFinished(ev2 -> {
                            FadeTransition fadeOut = new FadeTransition(Duration.millis(350), root);
                            fadeOut.setToValue(0);
                            fadeOut.setOnFinished(ev3 -> openDashboard(stage, role));
                            fadeOut.play();
                        });
                        progDone.play();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    loginProgress.setVisible(false);
                    loginBtn.setDisable(false);
                    loginBtn.setText("Sign In  →");
                    statusLabel.setText("⚠  Cannot connect to server. Please contact your administrator.");
                    statusLabel.setVisible(true);
                }
            });
            authDelay.play();
        });

        // Enter key support
        pass.setOnAction(e -> loginBtn.fire());
        user.setOnAction(e -> pass.requestFocus());

        root.getChildren().addAll(leftPanel, rightPanel);

        // ── Entry animation ───────────────────────────────
        root.setOpacity(0);
        loginCard.setTranslateY(30);
        FadeTransition fadeIn = new FadeTransition(Duration.millis(700), root);
        fadeIn.setToValue(1); fadeIn.play();
        TranslateTransition slideUp = new TranslateTransition(Duration.millis(600), loginCard);
        slideUp.setToY(0); slideUp.setInterpolator(Interpolator.SPLINE(0.16, 1, 0.3, 1)); slideUp.play();

        // Stagger brand content entry
        brandContent.setOpacity(0);
        brandContent.setTranslateX(-20);
        FadeTransition brandFade = new FadeTransition(Duration.millis(800), brandContent);
        brandFade.setToValue(1); brandFade.setDelay(Duration.millis(200)); brandFade.play();
        TranslateTransition brandSlide = new TranslateTransition(Duration.millis(700), brandContent);
        brandSlide.setToX(0); brandSlide.setDelay(Duration.millis(200));
        brandSlide.setInterpolator(Interpolator.SPLINE(0.16, 1, 0.3, 1)); brandSlide.play();

        Scene scene = new Scene(root, 1100, 680);
        stage.setScene(scene);
        stage.setTitle("Retail AI Enterprise Platform");
        stage.setResizable(false);
        stage.show();
    }

    // ─── Login Brand Panel Helpers ────────────────────────────────────────────

    private VBox buildFloatingDataNode(String value, String color) {
        Label val = new Label(value);
        val.setStyle(
            "-fx-text-fill:" + color + ";-fx-font-size:11px;-fx-font-weight:bold;" +
            "-fx-background-color:" + color + "15;" +
            "-fx-background-radius:8;-fx-border-color:" + color + "44;" +
            "-fx-border-radius:8;-fx-border-width:1;-fx-padding:5 10;"
        );
        val.setEffect(new DropShadow(10, Color.web(color, 0.4)));
        VBox box = new VBox(val);
        box.setAlignment(Pos.CENTER);
        return box;
    }

    private VBox buildLoginMetricStrip() {
        // 3 quick metric indicators
        String[][] metrics = {
            {ACCENT_CYAN,   "◈", "Revenue",   "Real-time"},
            {ACCENT_GREEN,  "▣", "Inventory", "Live sync"},
            {ACCENT_AMBER,  "◉", "Analytics", "AI-driven"}
        };
        HBox strip = new HBox(0);
        strip.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:14;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:14;-fx-border-width:1;"
        );
        for (int i = 0; i < metrics.length; i++) {
            String[] m = metrics[i];
            Label icon  = new Label(m[1]);
            icon.setStyle("-fx-text-fill:" + m[0] + ";-fx-font-size:14px;");
            Label title = new Label(m[2]);
            title.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:12px;-fx-font-weight:bold;");
            Label sub   = new Label(m[3]);
            sub.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;");
            VBox cell   = new VBox(3, new HBox(6, icon, title), sub);
            cell.setPadding(new Insets(14, 18, 14, 18));
            HBox.setHgrow(cell, Priority.ALWAYS);
            strip.getChildren().add(cell);
            if (i < metrics.length - 1) {
                Region divR = new Region();
                divR.setPrefWidth(1); divR.setPrefHeight(50);
                divR.setStyle("-fx-background-color:" + BORDER + ";");
                VBox divWrapper = new VBox(divR);
                divWrapper.setAlignment(Pos.CENTER);
                strip.getChildren().add(divWrapper);
            }
        }
        VBox wrapper = new VBox(strip);
        return wrapper;
    }

    private VBox buildLoginFeatureBullets() {
        String[][] features = {
            {ACCENT_BLUE,   "⬡", "Multi-role access control",    "Admin & staff permission levels"},
            {ACCENT_GREEN,  "◈", "Real-time inventory tracking",  "Live stock alerts & forecasting"},
            {ACCENT_PURPLE, "◎", "AI-powered sales predictions",  "Machine learning revenue engine"}
        };
        VBox box = new VBox(10);
        for (String[] f : features) {
            Label icon    = new Label(f[1]);
            icon.setStyle("-fx-text-fill:" + f[0] + ";-fx-font-size:14px;" +
                "-fx-background-color:" + f[0] + "18;-fx-background-radius:6;-fx-padding:5 7;");
            Label title   = new Label(f[2]);
            title.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:12px;-fx-font-weight:bold;");
            Label subLbl  = new Label(f[3]);
            subLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:11px;");
            VBox textCol  = new VBox(2, title, subLbl);
            HBox row      = new HBox(12, icon, textCol);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(10, 14, 10, 14));
            row.setStyle(
                "-fx-background-color:" + BG_CARD + ";" +
                "-fx-background-radius:10;-fx-border-color:" + BORDER + ";" +
                "-fx-border-radius:10;-fx-border-width:1;"
            );
            box.getChildren().add(row);
        }
        return box;
    }

    // ─── DASHBOARD SHELL ─────────────────────────────────────────────────────

    private void openDashboard(Stage stage, String role) {
        BorderPane root = new BorderPane();
        root.setLeft(createSidebar(stage, role));
        root.setTop(createHeader(role));
        root.setCenter(contentArea);

        contentArea.setStyle("-fx-background-color:" + BG_DEEP + ";");
        contentArea.setPadding(new Insets(30));
        contentArea.getChildren().setAll(createHomeDashboard());

        stage.setScene(new Scene(root, 1280, 800));
        stage.setTitle("Retail AI — " + role);
        stage.setResizable(true);
        stage.show();
    }

    // ─── HEADER ──────────────────────────────────────────────────────────────

    private HBox createHeader(String role) {
        Label title = new Label("Retail AI  ·  Business Intelligence");
        title.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:16px;-fx-font-weight:bold;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label rolePill = new Label(role);
        rolePill.setStyle(
            "-fx-background-color:" + (role.equals("ADMIN") ? ACCENT_BLUE : BG_ELEVATED) + ";" +
            "-fx-text-fill:white;-fx-background-radius:20;-fx-padding:4 14;" +
            "-fx-font-size:12px;-fx-font-weight:bold;"
        );

        Label clock = new Label();
        clock.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:13px;");
        Timeline t = new Timeline(new KeyFrame(Duration.seconds(1),
                e -> clock.setText(java.time.LocalTime.now().withNano(0).toString())));
        t.setCycleCount(Timeline.INDEFINITE);
        t.play();

        HBox header = new HBox(18, title, spacer, clock, rolePill);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(0, 28, 0, 28));
        header.setPrefHeight(58);
        header.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-border-color:transparent transparent " + BORDER + " transparent;" +
            "-fx-border-width:1;"
        );
        return header;
    }

    // ─── SIDEBAR ─────────────────────────────────────────────────────────────

    private VBox createSidebar(Stage stage, String role) {
        VBox side = new VBox();
        side.setPrefWidth(230);
        side.setStyle("-fx-background-color:" + BG_CARD + ";");

        Label logo = new Label("⬡  RetailAI");
        logo.setStyle(
            "-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:18px;" +
            "-fx-font-weight:bold;-fx-padding:28 24 18 24;"
        );

        Separator sep = new Separator();
        sep.setStyle("-fx-background-color:" + BORDER + ";");

        VBox navSection = new VBox(4);
        navSection.setPadding(new Insets(16, 12, 16, 12));

        Label navLabel = new Label("NAVIGATION");
        navLabel.setStyle(
            "-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;" +
            "-fx-font-weight:bold;-fx-padding:0 12 8 12;"
        );

        Button dash      = sideBtn("Dashboard",  "⊞");
        Button inventory = sideBtn("Inventory",   "▣");
        Button sales     = sideBtn("Sales",       "◈");
        Button analytics = sideBtn("Analytics",   "◉");

        dash.setOnAction(e      -> { setSideActive(dash, inventory, sales, analytics);      contentArea.getChildren().setAll(createHomeDashboard()); });
        inventory.setOnAction(e -> { setSideActive(inventory, dash, sales, analytics);      contentArea.getChildren().setAll(createInventoryPane()); });
        sales.setOnAction(e     -> { setSideActive(sales, dash, inventory, analytics);      contentArea.getChildren().setAll(createSalesPane()); });
        analytics.setOnAction(e -> { setSideActive(analytics, dash, inventory, sales);      contentArea.getChildren().setAll(createAnalyticsPane()); });

        setSideActive(dash, inventory, sales, analytics);

        navSection.getChildren().add(navLabel);
        navSection.getChildren().addAll(dash, inventory, sales);
        if (role.equals("ADMIN")) navSection.getChildren().add(analytics);

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        Separator sep2 = new Separator();
        sep2.setStyle("-fx-background-color:" + BORDER + ";");

        Button logout = sideBtn("Logout", "⏻");
        logout.setOnAction(e -> showLoginScreen(stage));
        VBox bottomSection = new VBox(logout);
        bottomSection.setPadding(new Insets(8, 12, 20, 12));

        side.getChildren().addAll(logo, sep, navSection, spacer, sep2, bottomSection);
        return side;
    }

    private Button sideBtn(String text, String icon) {
        Label iconLbl = new Label(icon);
        iconLbl.setMinWidth(22);
        iconLbl.setStyle("-fx-font-size:15px;-fx-text-fill:" + TEXT_SECONDARY + ";");
        Label textLbl = new Label(text);
        textLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:14px;");
        HBox content = new HBox(12, iconLbl, textLbl);
        content.setAlignment(Pos.CENTER_LEFT);

        Button b = new Button();
        b.setGraphic(content);
        b.setPrefWidth(206);
        b.setPrefHeight(42);
        b.setStyle("-fx-background-color:transparent;-fx-background-radius:10;-fx-cursor:hand;-fx-alignment:center-left;-fx-padding:0 12;");
        b.setOnMouseEntered(e -> { if (!b.getStyle().contains(ACCENT_BLUE))
            b.setStyle("-fx-background-color:" + BG_SURFACE + ";-fx-background-radius:10;-fx-cursor:hand;-fx-alignment:center-left;-fx-padding:0 12;"); });
        b.setOnMouseExited(e  -> { if (!b.getStyle().contains(ACCENT_BLUE))
            b.setStyle("-fx-background-color:transparent;-fx-background-radius:10;-fx-cursor:hand;-fx-alignment:center-left;-fx-padding:0 12;"); });
        return b;
    }

    private void setSideActive(Button active, Button... others) {
        HBox ac = (HBox) active.getGraphic();
        ((Label) ac.getChildren().get(0)).setStyle("-fx-font-size:15px;-fx-text-fill:" + ACCENT_BLUE + ";");
        ((Label) ac.getChildren().get(1)).setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        active.setStyle(
            "-fx-background-color:linear-gradient(to right," + ACCENT_BLUE + "22," + ACCENT_BLUE + "11);" +
            "-fx-background-radius:10;-fx-border-color:" + ACCENT_BLUE + ";" +
            "-fx-border-radius:10;-fx-border-width:0 0 0 3;-fx-cursor:hand;-fx-alignment:center-left;-fx-padding:0 12;"
        );
        for (Button b : others) {
            HBox hb = (HBox) b.getGraphic();
            ((Label) hb.getChildren().get(0)).setStyle("-fx-font-size:15px;-fx-text-fill:" + TEXT_SECONDARY + ";");
            ((Label) hb.getChildren().get(1)).setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:14px;");
            b.setStyle("-fx-background-color:transparent;-fx-background-radius:10;-fx-cursor:hand;-fx-alignment:center-left;-fx-padding:0 12;");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── HOME DASHBOARD (MODERNIZED) ─────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    private ScrollPane createHomeDashboard() {
        VBox root = new VBox(24);
        root.setPadding(new Insets(6, 6, 40, 6));

        // ── Date + greeting header ─────────────────────────────────────────────
        String hour = LocalTime.now().toString();
        int h = LocalTime.now().getHour();
        String greeting = h < 12 ? "Good Morning" : h < 17 ? "Good Afternoon" : "Good Evening";
        String dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d yyyy"));

        Label greetLbl = new Label(greeting + "  ·  Dashboard");
        greetLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:22px;-fx-font-weight:bold;");
        Label dateLbl = new Label(dateStr);
        dateLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:13px;");

        Button refreshDash = secondaryBtn("↺  Refresh");
        Region dashSpacer = new Region(); HBox.setHgrow(dashSpacer, Priority.ALWAYS);

        // Live system clock badge
        Label liveClockBadge = new Label();
        liveClockBadge.setStyle(
            "-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:13px;-fx-font-weight:bold;" +
            "-fx-background-color:" + ACCENT_CYAN + "15;-fx-background-radius:8;" +
            "-fx-border-color:" + ACCENT_CYAN + "44;-fx-border-radius:8;-fx-border-width:1;-fx-padding:5 12;"
        );
        Timeline liveClk = new Timeline(new KeyFrame(Duration.seconds(1),
            e -> liveClockBadge.setText("⬤  LIVE  " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")))));
        liveClk.setCycleCount(Timeline.INDEFINITE); liveClk.play();

        HBox dashHeader = new HBox(14, new VBox(4, greetLbl, dateLbl), dashSpacer, liveClockBadge, refreshDash);
        dashHeader.setAlignment(Pos.CENTER_LEFT);

        // ── Data containers ───────────────────────────────────────────────────
        int[] totalProducts  = {0};
        double[] predicted   = {0};
        double[] growth      = {0};
        double[] totalRev    = {0};
        double[] inventoryVal= {0};
        long[] lowStockCount = {0};
        String[] topProduct  = {"—"};
        double[] avgMargin   = {0};
        Map<String, Double> revenueMap = new LinkedHashMap<>();
        List<ProductBean> allProds = new ArrayList<>();

        try {
            allProds = service.getAllProducts();
            totalProducts[0] = allProds.size();
            Map<String, Double> insights = service.getSalesPredictionInsights();
            predicted[0] = insights.get("prediction");
            growth[0]    = insights.get("growth");
            Map<String, Double> rev = service.getMonthlyRevenue();
            revenueMap.putAll(rev);
            totalRev[0]     = rev.values().stream().mapToDouble(Double::doubleValue).sum();
            inventoryVal[0] = allProds.stream().mapToDouble(p -> p.getSellingPrice() * p.getStockQuantity()).sum();
            lowStockCount[0]= allProds.stream().filter(p -> p.getStockQuantity() < 10).count();
            avgMargin[0]    = allProds.stream().mapToDouble(p -> p.getSellingPrice() == 0 ? 0 :
                (p.getSellingPrice() - p.getCostPrice()) / p.getSellingPrice() * 100).average().orElse(0);
            Map<String, Integer> topSell = service.getTopSellingProducts();
            topProduct[0] = topSell.entrySet().stream().max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey).orElse("—");
        } catch (Exception e) { e.printStackTrace(); }

        // ── PRIMARY KPI ROW (6 cards) ─────────────────────────────────────────
        HBox kpiRow = new HBox(14);
        boolean growthPositive = growth[0] >= 0;
        String growthColor = growthPositive ? ACCENT_GREEN : ACCENT_RED;
        String growthArrow = growthPositive ? "▲" : "▼";

        kpiRow.getChildren().addAll(
            dashKpiCard("Total Products",    String.valueOf(totalProducts[0]),
                "items in catalog", ACCENT_BLUE, "▣",
                null, null),
            dashKpiCard("Total Revenue",     "₹ " + compactNum(totalRev[0]),
                "all-time recorded", ACCENT_CYAN, "◈",
                null, null),
            dashKpiCard("Predicted Revenue", "₹ " + compactNum(predicted[0]),
                "next month forecast", ACCENT_PURPLE, "◎",
                null, null),
            dashKpiCard("Growth Rate",       String.format("%.1f", growth[0]) + "%",
                "vs previous period", growthColor, growthArrow,
                null, null),
            dashKpiCard("Inventory Value",   "₹ " + compactNum(inventoryVal[0]),
                "stock at sell price", ACCENT_GREEN, "⊞",
                null, null),
            dashKpiCard("Low Stock Alerts",  String.valueOf(lowStockCount[0]),
                "items critical", lowStockCount[0] > 0 ? ACCENT_RED : ACCENT_GREEN, "⚠",
                null, null)
        );
        for (javafx.scene.Node n : kpiRow.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);

        // ── MIDDLE ROW: Revenue Sparkline + Donut + AI Reco ───────────────────
        VBox revChartCard = buildDashRevenueSparkline(revenueMap);
        HBox.setHgrow(revChartCard, Priority.ALWAYS);

        VBox donutCard = buildDashStockDonut(allProds);
        donutCard.setPrefWidth(260);

        VBox aiRecoCard = buildDashAiReco(growth[0], predicted[0], lowStockCount[0], topProduct[0], avgMargin[0]);
        aiRecoCard.setPrefWidth(280);

        HBox midRow = new HBox(14, revChartCard, donutCard, aiRecoCard);

        // ── BOTTOM ROW: Activity Feed + Top Products + System Health ──────────
        VBox activityCard = buildDashActivityFeed(allProds, revenueMap);
        HBox.setHgrow(activityCard, Priority.ALWAYS);

        VBox topProdCard  = buildDashTopProducts();
        topProdCard.setPrefWidth(280);

        VBox systemCard   = buildDashSystemHealth(totalProducts[0], lowStockCount[0], avgMargin[0], growth[0]);
        systemCard.setPrefWidth(260);

        HBox bottomRow = new HBox(14, activityCard, topProdCard, systemCard);

        root.getChildren().addAll(dashHeader, kpiRow, midRow, bottomRow);

        refreshDash.setOnAction(e -> {
            contentArea.getChildren().setAll(createHomeDashboard());
        });

        root.setOpacity(0);
        FadeTransition pageIn = new FadeTransition(Duration.millis(500), root);
        pageIn.setToValue(1); pageIn.play();

        ScrollPane sp = new ScrollPane(root);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background:transparent;-fx-background-color:transparent;");
        return sp;
    }

    // ─── Dashboard KPI Card ───────────────────────────────────────────────────
    private VBox dashKpiCard(String title, String value, String detail,
                              String accent, String icon,
                              String trendPct, String trendDir) {
        Region accentLine = new Region();
        accentLine.setPrefHeight(3);
        accentLine.setStyle("-fx-background-color:linear-gradient(to right," + accent + ",transparent);-fx-background-radius:3 3 0 0;");

        Label iconLbl = new Label(icon);
        iconLbl.setStyle("-fx-text-fill:" + accent + ";-fx-font-size:18px;" +
            "-fx-background-color:" + accent + "18;-fx-background-radius:8;-fx-padding:7 9;");

        Label titleLbl = new Label(title.toUpperCase());
        titleLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;-fx-letter-spacing:0.8;");

        Label valueLbl = new Label(value);
        valueLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:22px;-fx-font-weight:bold;");

        Label detailLbl = new Label(detail);
        detailLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:11px;");

        VBox textBlock = new VBox(3, titleLbl, valueLbl, detailLbl);
        HBox inner = new HBox(12, iconLbl, textBlock);
        inner.setAlignment(Pos.CENTER_LEFT);
        inner.setPadding(new Insets(16, 18, 18, 18));

        VBox card = new VBox(0, accentLine, inner);
        card.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:14;" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:14;" +
            "-fx-border-width:1;" +
            "-fx-cursor:hand;"
        );
        card.setEffect(new DropShadow(16, Color.web("#000000", 0.38)));

        card.setOnMouseEntered(e -> {
            card.setStyle(
                "-fx-background-color:" + BG_SURFACE + ";" +
                "-fx-background-radius:14;" +
                "-fx-border-color:" + accent + ";" +
                "-fx-border-radius:14;-fx-border-width:1;-fx-cursor:hand;"
            );
            card.setEffect(new DropShadow(28, Color.web(accent, 0.25)));
        });
        card.setOnMouseExited(e -> {
            card.setStyle(
                "-fx-background-color:" + BG_CARD + ";" +
                "-fx-background-radius:14;" +
                "-fx-border-color:" + BORDER + ";" +
                "-fx-border-radius:14;-fx-border-width:1;-fx-cursor:hand;"
            );
            card.setEffect(new DropShadow(16, Color.web("#000000", 0.38)));
        });

        ScaleTransition pulse = new ScaleTransition(Duration.millis(300), valueLbl);
        pulse.setFromX(0.85); pulse.setFromY(0.85);
        pulse.setToX(1.0); pulse.setToY(1.0);
        pulse.play();

        HBox.setHgrow(card, Priority.ALWAYS);
        return card;
    }

    // ─── Dashboard: Revenue Sparkline Card ───────────────────────────────────
    private VBox buildDashRevenueSparkline(Map<String, Double> revenueMap) {
        Label lbl = new Label("Revenue Trend");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Monthly performance overview");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");

        double total = revenueMap.values().stream().mapToDouble(Double::doubleValue).sum();
        Label totalLbl = new Label("Total  ₹ " + compactNum(total));
        totalLbl.setStyle(
            "-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:13px;-fx-font-weight:bold;" +
            "-fx-background-color:" + ACCENT_CYAN + "15;-fx-background-radius:7;" +
            "-fx-border-color:" + ACCENT_CYAN + "33;-fx-border-radius:7;-fx-border-width:1;-fx-padding:4 10;"
        );
        Region hsp = new Region(); HBox.setHgrow(hsp, Priority.ALWAYS);
        HBox titleRow = new HBox(10, new VBox(2, lbl, sub), hsp, totalLbl);
        titleRow.setAlignment(Pos.CENTER_LEFT);

        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        xAxis.setStyle("-fx-tick-label-font-size:11px;");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        yAxis.setStyle("-fx-tick-label-font-size:11px;");
        LineChart<String, Number> chart = new LineChart<>(xAxis, yAxis);
        chart.setTitle(null); chart.setCreateSymbols(true); chart.setAnimated(true);
        chart.setPrefHeight(210); chart.setLegendVisible(false);
        chart.setStyle("-fx-background-color:transparent;");

        if (!revenueMap.isEmpty()) {
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Revenue");
            for (String m : revenueMap.keySet().stream().sorted().toList())
                series.getData().add(new XYChart.Data<>(m, revenueMap.get(m)));
            chart.getData().add(series);
        } else {
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun"};
            double[] vals   = {0, 0, 0, 0, 0, 0};
            for (int i = 0; i < months.length; i++)
                series.getData().add(new XYChart.Data<>(months[i], vals[i]));
            chart.getData().add(series);
        }

        Platform.runLater(() -> {
            try {
                javafx.scene.Node bg = chart.lookup(".chart-plot-background");
                if (bg != null) bg.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:8;");
                chart.lookupAll(".chart-series-line").forEach(n ->
                    n.setStyle("-fx-stroke:" + ACCENT_CYAN + ";-fx-stroke-width:2.5;"));
                chart.lookupAll(".chart-line-symbol").forEach(n ->
                    n.setStyle("-fx-background-color:" + ACCENT_CYAN + "," + BG_CARD + ";-fx-background-radius:6;"));
                chart.lookupAll(".chart-horizontal-grid-lines").forEach(n ->
                    n.setStyle("-fx-stroke:" + BORDER + ";"));
                chart.lookupAll(".chart-vertical-grid-lines").forEach(n ->
                    n.setStyle("-fx-stroke:transparent;"));
            } catch (Exception ignored) {}
        });

        HBox monthDots = new HBox(12);
        monthDots.setAlignment(Pos.CENTER_LEFT);
        monthDots.setPadding(new Insets(6, 0, 0, 4));
        if (!revenueMap.isEmpty()) {
            double maxRev = revenueMap.values().stream().mapToDouble(Double::doubleValue).max().orElse(1);
            for (Map.Entry<String, Double> en : revenueMap.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey()).collect(Collectors.toList())) {
                double pct = maxRev == 0 ? 0 : en.getValue() / maxRev;
                String c = pct > 0.7 ? ACCENT_CYAN : pct > 0.4 ? ACCENT_BLUE : TEXT_MUTED;
                VBox dot = new VBox(3);
                Circle d = new Circle(4, Color.web(c));
                Label ml = new Label(en.getKey());
                ml.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;");
                dot.getChildren().addAll(d, ml);
                dot.setAlignment(Pos.CENTER);
                monthDots.getChildren().add(dot);
            }
        }

        VBox card = new VBox(14, titleRow, chart, monthDots);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(18, Color.web("#000000", 0.4)));
        return card;
    }

    // ─── Dashboard: Stock Donut Card ─────────────────────────────────────────
    private VBox buildDashStockDonut(List<ProductBean> prods) {
        Label lbl = new Label("Stock Health");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Inventory distribution");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");

        long critical = prods.stream().filter(p -> p.getStockQuantity() < 10).count();
        long warning  = prods.stream().filter(p -> p.getStockQuantity() >= 10 && p.getStockQuantity() < 30).count();
        long healthy  = prods.stream().filter(p -> p.getStockQuantity() >= 30).count();
        int  total    = prods.size();

        double critPct   = total == 0 ? 0 : (double) critical / total;
        double warnPct   = total == 0 ? 0 : (double) warning  / total;
        double healPct   = total == 0 ? 0 : (double) healthy  / total;

        StackPane donut = new StackPane();
        donut.setPrefSize(140, 140);
        donut.setMaxSize(140, 140);

        Circle bgRing = new Circle(58);
        bgRing.setFill(Color.TRANSPARENT);
        bgRing.setStroke(Color.web(BG_ELEVATED));
        bgRing.setStrokeWidth(18);

        double totalAngle = 360.0;
        double gapAngle   = 4.0;

        Arc critArc = buildDonutArc(critPct, totalAngle, 0, gapAngle, ACCENT_RED);
        Arc warnArc = buildDonutArc(warnPct, totalAngle, critPct * 360 + gapAngle, gapAngle, ACCENT_AMBER);
        Arc healArc = buildDonutArc(healPct, totalAngle, (critPct + warnPct) * 360 + gapAngle * 2, gapAngle, ACCENT_GREEN);

        Label centerVal = new Label(String.valueOf(total));
        centerVal.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:26px;-fx-font-weight:bold;");
        Label centerSub = new Label("products");
        centerSub.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:11px;");
        VBox centerBox = new VBox(0, centerVal, centerSub);
        centerBox.setAlignment(Pos.CENTER);

        donut.getChildren().addAll(bgRing, critArc, warnArc, healArc, centerBox);

        VBox legend = new VBox(10,
            donutLegend("Critical", critical, ACCENT_RED),
            donutLegend("Warning",  warning,  ACCENT_AMBER),
            donutLegend("Healthy",  healthy,  ACCENT_GREEN)
        );

        HBox donutRow = new HBox(18, donut, legend);
        donutRow.setAlignment(Pos.CENTER_LEFT);

        VBox bars = new VBox(8,
            dashStockBar("Critical", critPct, ACCENT_RED),
            dashStockBar("Warning",  warnPct, ACCENT_AMBER),
            dashStockBar("Healthy",  healPct, ACCENT_GREEN)
        );

        VBox card = new VBox(14, new VBox(2, lbl, sub), donutRow, bars);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(18, Color.web("#000000", 0.4)));
        return card;
    }

    private Arc buildDonutArc(double pct, double totalDeg, double startOffset, double gap, String color) {
        double arcLen = Math.max(0, pct * totalDeg - gap);
        Arc arc = new Arc(70, 70, 58, 58, 90 - startOffset, -arcLen);
        arc.setType(javafx.scene.shape.ArcType.OPEN);
        arc.setFill(Color.TRANSPARENT);
        arc.setStroke(Color.web(color));
        arc.setStrokeWidth(18);
        arc.setStrokeLineCap(StrokeLineCap.ROUND);
        return arc;
    }

    private HBox donutLegend(String label, long count, String color) {
        Circle dot = new Circle(5, Color.web(color));
        Label nameLbl = new Label(label);
        nameLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
        Label cntLbl = new Label(String.valueOf(count));
        cntLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:13px;-fx-font-weight:bold;");
        HBox row = new HBox(8, dot, nameLbl, sp, cntLbl);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private VBox dashStockBar(String label, double pct, String color) {
        Label nameLbl = new Label(label);
        nameLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");
        Region bg = new Region(); bg.setPrefHeight(5); bg.setMaxWidth(Double.MAX_VALUE);
        bg.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:3;");
        Region fill = new Region(); fill.setPrefHeight(5);
        fill.setStyle("-fx-background-color:" + color + ";-fx-background-radius:3;");
        StackPane bar = new StackPane(bg, fill);
        StackPane.setAlignment(fill, Pos.CENTER_LEFT);
        Platform.runLater(() -> {
            fill.setPrefWidth(0);
            bar.widthProperty().addListener((obs, ov, nv) -> {
                Timeline tl = new Timeline(new KeyFrame(Duration.millis(600),
                    new KeyValue(fill.prefWidthProperty(), nv.doubleValue() * pct, Interpolator.EASE_BOTH)));
                tl.play();
            });
        });
        Label pctLbl = new Label(String.format("%.0f%%", pct * 100));
        pctLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:10px;-fx-font-weight:bold;");
        HBox topRow = new HBox(nameLbl, new Region() {{ HBox.setHgrow(this, Priority.ALWAYS); }}, pctLbl);
        return new VBox(4, topRow, bar);
    }

    // ─── Dashboard: AI Recommendation Card ────────────────────────────────────
    private VBox buildDashAiReco(double growth, double predicted, long lowStock,
                                   String topProduct, double avgMargin) {
        Label ico = new Label("◎");
        ico.setStyle("-fx-text-fill:" + ACCENT_PURPLE + ";-fx-font-size:20px;");

        ScaleTransition pulse = new ScaleTransition(Duration.millis(1200), ico);
        pulse.setFromX(1.0); pulse.setToX(1.18); pulse.setFromY(1.0); pulse.setToY(1.18);
        pulse.setAutoReverse(true); pulse.setCycleCount(Animation.INDEFINITE); pulse.play();

        Label lbl = new Label("AI Insights");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Smart recommendations");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");

        HBox titleRow = new HBox(10, ico, new VBox(2, lbl, sub));
        titleRow.setAlignment(Pos.CENTER_LEFT);

        Separator sep = new Separator(); sep.setStyle("-fx-background-color:" + BORDER + ";");

        List<String[]> recos = new ArrayList<>();
        if (growth > 10) {
            recos.add(new String[]{ACCENT_GREEN, "▲", "Strong growth (" + String.format("%.1f", growth) + "%). Scale inventory to meet demand."});
        } else if (growth > 0) {
            recos.add(new String[]{ACCENT_CYAN, "→", "Moderate growth. Optimise margins on low performers."});
        } else {
            recos.add(new String[]{ACCENT_RED, "▼", "Revenue declining. Review pricing & promotions urgently."});
        }
        if (lowStock > 0) {
            recos.add(new String[]{ACCENT_AMBER, "⚠", lowStock + " item(s) critically low. Restock immediately."});
        } else {
            recos.add(new String[]{ACCENT_GREEN, "✓", "All stock levels healthy. No urgent restocking needed."});
        }
        recos.add(new String[]{ACCENT_PURPLE, "◈", "Predicted next-month revenue: ₹ " + compactNum(predicted) + "."});
        if (!topProduct.equals("—")) {
            recos.add(new String[]{ACCENT_BLUE, "⊛", "Top seller: " + topProduct + ". Prioritise its stock."});
        }
        if (avgMargin < 15) {
            recos.add(new String[]{ACCENT_RED, "⬡", String.format("Avg margin %.1f%% is low. Review cost structures.", avgMargin)});
        } else {
            recos.add(new String[]{ACCENT_GREEN, "⬡", String.format("Avg margin %.1f%% is healthy.", avgMargin)});
        }

        VBox recoList = new VBox(10);
        for (String[] r : recos) {
            Label bullet = new Label(r[1]);
            bullet.setStyle("-fx-text-fill:" + r[0] + ";-fx-font-size:13px;-fx-min-width:16;");
            Label msg = new Label(r[2]);
            msg.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:12px;-fx-wrap-text:true;");
            msg.setWrapText(true);
            HBox row = new HBox(10, bullet, msg);
            row.setAlignment(Pos.TOP_LEFT);
            row.setPadding(new Insets(8, 12, 8, 12));
            row.setStyle("-fx-background-color:" + r[0] + "0D;-fx-background-radius:8;" +
                "-fx-border-color:" + r[0] + "33;-fx-border-radius:8;-fx-border-width:1;");
            recoList.getChildren().add(row);
        }

        Label badge = new Label("◎  Powered by Retail AI Engine");
        badge.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-padding:6 0 0 0;");

        VBox card = new VBox(14, titleRow, sep, recoList, badge);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;" +
            "-fx-border-color:" + ACCENT_PURPLE + "44;-fx-border-radius:16;-fx-border-width:1.5;");
        card.setEffect(new DropShadow(18, Color.web(ACCENT_PURPLE, 0.2)));
        return card;
    }

    // ─── Dashboard: Activity / Revenue Feed Card ───────────────────────────────
    private VBox buildDashActivityFeed(List<ProductBean> prods, Map<String, Double> revenueMap) {
        Label lbl = new Label("Business Activity");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Key events and metrics at a glance");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");

        Label tblLbl = new Label("TOP MARGIN PRODUCTS");
        tblLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;-fx-padding:0 0 4 0;");

        VBox rows = new VBox(0);
        List<ProductBean> topMargin = prods.stream()
            .filter(p -> p.getSellingPrice() > 0)
            .sorted(Comparator.comparingDouble(p ->
                -((p.getSellingPrice() - p.getCostPrice()) / p.getSellingPrice() * 100)))
            .limit(5)
            .collect(Collectors.toList());

        for (int i = 0; i < topMargin.size(); i++) {
            ProductBean p = topMargin.get(i);
            double margin = p.getSellingPrice() == 0 ? 0 :
                (p.getSellingPrice() - p.getCostPrice()) / p.getSellingPrice() * 100;
            String c = margin >= 25 ? ACCENT_GREEN : margin >= 12 ? ACCENT_AMBER : ACCENT_RED;

            Label rank = new Label("#" + (i + 1));
            rank.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:11px;-fx-min-width:22;");
            Label name = new Label(p.getName());
            name.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;");
            name.setMaxWidth(160);
            Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);

            Region bgBar = new Region(); bgBar.setPrefSize(60, 5);
            bgBar.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:3;");
            Region fillBar = new Region(); fillBar.setPrefHeight(5);
            fillBar.setStyle("-fx-background-color:" + c + ";-fx-background-radius:3;");
            StackPane miniBar = new StackPane(bgBar, fillBar);
            StackPane.setAlignment(fillBar, Pos.CENTER_LEFT);
            double pct = Math.min(margin / 60.0, 1.0);
            Platform.runLater(() -> fillBar.setPrefWidth(60 * pct));

            Label mLbl = new Label(String.format("%.1f%%", margin));
            mLbl.setStyle("-fx-text-fill:" + c + ";-fx-font-size:12px;-fx-font-weight:bold;-fx-min-width:45;-fx-alignment:center-right;");

            HBox row = new HBox(10, rank, name, sp, miniBar, mLbl);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(9, 6, 9, 6));
            row.setStyle("-fx-border-color:transparent transparent " + BORDER + " transparent;-fx-border-width:1;");
            row.setOnMouseEntered(e -> row.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:8;"));
            row.setOnMouseExited(e  -> row.setStyle("-fx-border-color:transparent transparent " + BORDER + " transparent;-fx-border-width:1;"));
            rows.getChildren().add(row);
        }

        if (topMargin.isEmpty()) {
            Label empty = new Label("No product data available");
            empty.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:13px;-fx-padding:12 0;");
            rows.getChildren().add(empty);
        }

        Label revLbl = new Label("MONTHLY REVENUE SUMMARY");
        revLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;-fx-padding:8 0 4 0;");

        HBox revRow = new HBox(10);
        revRow.setAlignment(Pos.CENTER_LEFT);
        if (!revenueMap.isEmpty()) {
            double maxRev = revenueMap.values().stream().mapToDouble(Double::doubleValue).max().orElse(1);
            for (Map.Entry<String, Double> en : revenueMap.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey()).collect(Collectors.toList())) {
                double h = maxRev == 0 ? 2 : Math.max(4, en.getValue() / maxRev * 60);
                String barColor = en.getValue() >= maxRev * 0.8 ? ACCENT_CYAN
                    : en.getValue() >= maxRev * 0.4 ? ACCENT_BLUE : TEXT_MUTED;

                Region barR = new Region();
                barR.setPrefSize(24, h);
                barR.setStyle("-fx-background-color:" + barColor + ";-fx-background-radius:3 3 0 0;");
                Label mLabel = new Label(en.getKey().length() > 3 ? en.getKey().substring(0,3) : en.getKey());
                mLabel.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:9px;");

                VBox col = new VBox(2, barR, mLabel);
                col.setAlignment(Pos.BOTTOM_CENTER);
                col.setPrefHeight(82);

                Tooltip tt = new Tooltip(en.getKey() + ": ₹ " + String.format("%,.0f", en.getValue()));
                Tooltip.install(barR, tt);

                revRow.getChildren().add(col);
            }
        } else {
            Label noData = new Label("No revenue data yet");
            noData.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:12px;");
            revRow.getChildren().add(noData);
        }
        revRow.setPadding(new Insets(6, 4, 0, 4));
        revRow.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:10;-fx-padding:12 10;");

        Separator divSep = new Separator(); divSep.setStyle("-fx-background-color:" + BORDER + ";");

        VBox card = new VBox(14, new VBox(2, lbl, sub), divSep, tblLbl, rows, revLbl, revRow);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(18, Color.web("#000000", 0.4)));
        return card;
    }

    // ─── Dashboard: Top Products Card ─────────────────────────────────────────
    private VBox buildDashTopProducts() {
        Label lbl = new Label("Top Selling Products");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("By units sold");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");

        VBox content = new VBox(8);
        try {
            Map<String, Integer> topSell = service.getTopSellingProducts();
            int maxQty = topSell.values().stream().mapToInt(Integer::intValue).max().orElse(1);
            String[] palette = {ACCENT_BLUE, ACCENT_CYAN, ACCENT_GREEN, ACCENT_AMBER, ACCENT_PURPLE};
            int[] idx = {0};

            topSell.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(6)
                .forEach(en -> {
                    String c = palette[idx[0] % palette.length];
                    double pct = maxQty == 0 ? 0 : (double) en.getValue() / maxQty;

                    Label rank = new Label(String.valueOf(idx[0] + 1));
                    rank.setStyle("-fx-text-fill:" + c + ";-fx-font-size:13px;-fx-font-weight:bold;-fx-min-width:18;");
                    Label name = new Label(en.getKey());
                    name.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:12px;");
                    name.setMaxWidth(140);
                    Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
                    Label qty = new Label(String.valueOf(en.getValue()));
                    qty.setStyle("-fx-text-fill:" + c + ";-fx-font-size:12px;-fx-font-weight:bold;");

                    Region bg = new Region(); bg.setPrefSize(Double.MAX_VALUE, 4);
                    bg.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:2;");
                    Region fill = new Region(); fill.setPrefHeight(4);
                    fill.setStyle("-fx-background-color:" + c + ";-fx-background-radius:2;");
                    HBox.setHgrow(bg, Priority.ALWAYS);
                    StackPane bar = new StackPane(bg, fill);
                    StackPane.setAlignment(fill, Pos.CENTER_LEFT);
                    Platform.runLater(() -> {
                        bar.widthProperty().addListener((obs, ov, nv) -> {
                            Timeline tl = new Timeline(new KeyFrame(Duration.millis(500),
                                new KeyValue(fill.prefWidthProperty(), nv.doubleValue() * pct, Interpolator.EASE_BOTH)));
                            tl.play();
                        });
                    });

                    HBox nameRow = new HBox(8, rank, name, sp, qty);
                    nameRow.setAlignment(Pos.CENTER_LEFT);
                    VBox item = new VBox(5, nameRow, bar);
                    item.setPadding(new Insets(8, 10, 8, 10));
                    item.setStyle("-fx-background-color:transparent;-fx-background-radius:8;-fx-cursor:hand;");
                    item.setOnMouseEntered(e -> item.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:8;-fx-cursor:hand;"));
                    item.setOnMouseExited(e  -> item.setStyle("-fx-background-color:transparent;-fx-background-radius:8;-fx-cursor:hand;"));

                    content.getChildren().add(item);
                    idx[0]++;
                });

            if (topSell.isEmpty()) {
                Label empty = new Label("No sales data yet");
                empty.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:13px;-fx-padding:8 0;");
                content.getChildren().add(empty);
            }
        } catch (Exception e) { e.printStackTrace(); }

        Separator sep = new Separator(); sep.setStyle("-fx-background-color:" + BORDER + ";");

        VBox card = new VBox(14, new VBox(2, lbl, sub), sep, content);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(18, Color.web("#000000", 0.4)));
        return card;
    }

    // ─── Dashboard: System Health Card ────────────────────────────────────────
    private VBox buildDashSystemHealth(int totalProds, long lowStock, double avgMargin, double growth) {
        Label lbl = new Label("System Status");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Platform health & metrics");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");

        VBox statusList = new VBox(10);

        String[][] statuses = {
            {totalProds > 0 ? ACCENT_GREEN : ACCENT_RED,
             totalProds > 0 ? "✓" : "✕",
             "Product Catalog",
             totalProds + " products active"},
            {lowStock == 0 ? ACCENT_GREEN : lowStock < 3 ? ACCENT_AMBER : ACCENT_RED,
             lowStock == 0 ? "✓" : "⚠",
             "Stock Levels",
             lowStock == 0 ? "All items healthy" : lowStock + " item(s) critical"},
            {growth >= 0 ? ACCENT_GREEN : ACCENT_RED,
             growth >= 0 ? "▲" : "▼",
             "Sales Trend",
             growth >= 0 ? "Positive growth" : "Revenue declining"},
            {avgMargin >= 15 ? ACCENT_GREEN : avgMargin >= 8 ? ACCENT_AMBER : ACCENT_RED,
             "◉",
             "Profit Margins",
             String.format("Avg %.1f%% margin", avgMargin)},
            {ACCENT_CYAN, "⬤", "RMI Service", "Connected & operational"},
            {ACCENT_CYAN, "⬤", "Database",    "Live & synced"}
        };

        for (String[] s : statuses) {
            String color = s[0], icon = s[1], name = s[2], detail = s[3];

            Circle dot = new Circle(5, Color.web(color));
            if (color.equals(ACCENT_CYAN)) {
                FadeTransition ft = new FadeTransition(Duration.millis(900), dot);
                ft.setFromValue(0.3); ft.setToValue(1.0);
                ft.setAutoReverse(true); ft.setCycleCount(Animation.INDEFINITE);
                ft.play();
            }

            Label icoLbl = new Label(icon);
            icoLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:12px;-fx-min-width:14;");
            Label nameLbl = new Label(name);
            nameLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:12px;-fx-font-weight:bold;");
            Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
            Label detailLbl = new Label(detail);
            detailLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:11px;");

            HBox row = new HBox(8, dot, icoLbl, nameLbl, sp, detailLbl);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(9, 10, 9, 10));
            row.setStyle("-fx-background-color:" + color + "0D;-fx-background-radius:8;" +
                "-fx-border-color:" + color + "22;-fx-border-radius:8;-fx-border-width:1;");
            statusList.getChildren().add(row);
        }

        Label uptimeLbl = new Label("⬡  System online  ·  " + LocalDate.now().format(DateTimeFormatter.ofPattern("MMM d, yyyy")));
        uptimeLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-padding:6 0 0 0;");

        Separator sep = new Separator(); sep.setStyle("-fx-background-color:" + BORDER + ";");

        VBox card = new VBox(14, new VBox(2, lbl, sub), sep, statusList, uptimeLbl);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(18, Color.web("#000000", 0.4)));
        return card;
    }

    private VBox kpiCard(String title, String value, String detail, String accent, String icon) {
        return dashKpiCard(title, value, detail, accent, icon, null, null);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── INVENTORY (MODERNIZED) ───────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    private ScrollPane createInventoryPane() {

        String[] activeFilter = {"ALL"};

        Label pageTitle = headingLabel("Inventory Management");
        Label pageSub   = makeSub("Manage products, monitor stock health, and track catalog value");

        Label totalProductsVal = new Label("—");
        totalProductsVal.setStyle("-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:22px;-fx-font-weight:bold;");
        Label inventoryValueVal = new Label("—");
        inventoryValueVal.setStyle("-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:22px;-fx-font-weight:bold;");
        Label lowStockVal = new Label("—");
        lowStockVal.setStyle("-fx-text-fill:" + ACCENT_RED + ";-fx-font-size:22px;-fx-font-weight:bold;");
        Label avgMarginVal = new Label("—");
        avgMarginVal.setStyle("-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:22px;-fx-font-weight:bold;");

        VBox invKpi1 = kpiMiniInv("Total Products",     totalProductsVal,  ACCENT_BLUE,   "▣");
        VBox invKpi2 = kpiMiniInv("Inventory Value",    inventoryValueVal, ACCENT_CYAN,   "◈");
        VBox invKpi3 = kpiMiniInv("Low Stock Alerts",   lowStockVal,       ACCENT_RED,    "⚠");
        VBox invKpi4 = kpiMiniInv("Avg Profit Margin",  avgMarginVal,      ACCENT_GREEN,  "◉");
        HBox.setHgrow(invKpi1, Priority.ALWAYS); HBox.setHgrow(invKpi2, Priority.ALWAYS);
        HBox.setHgrow(invKpi3, Priority.ALWAYS); HBox.setHgrow(invKpi4, Priority.ALWAYS);
        HBox invKpiRow = new HBox(14, invKpi1, invKpi2, invKpi3, invKpi4);

        Runnable updateKpis = () -> {
            try {
                List<ProductBean> all = service.getAllProducts();
                double tv   = all.stream().mapToDouble(p -> p.getSellingPrice() * p.getStockQuantity()).sum();
                long   low  = all.stream().filter(p -> p.getStockQuantity() < 10).count();
                double margin = all.stream().mapToDouble(p -> p.getSellingPrice() == 0 ? 0 :
                    (p.getSellingPrice() - p.getCostPrice()) / p.getSellingPrice() * 100).average().orElse(0);
                totalProductsVal.setText(String.valueOf(all.size()));
                inventoryValueVal.setText("₹" + compactNum(tv));
                lowStockVal.setText(String.valueOf(low));
                avgMarginVal.setText(String.format("%.1f%%", margin));
            } catch (Exception ignored) {}
        };
        updateKpis.run();

        TextField search = styledField("🔍  Search by product name...");
        search.setPrefWidth(320);

        HBox filterPills = new HBox(8);
        filterPills.setAlignment(Pos.CENTER_LEFT);
        Button[] pills = {
            filterPill("All",      "ALL",      ACCENT_BLUE),
            filterPill("Healthy",  "HEALTHY",  ACCENT_GREEN),
            filterPill("Warning",  "WARNING",  ACCENT_AMBER),
            filterPill("Critical", "CRITICAL", ACCENT_RED)
        };
        filterPills.getChildren().addAll(pills);
        setPillActive(pills[0], pills[1], pills[2], pills[3]);

        Region toolSpacer = new Region(); HBox.setHgrow(toolSpacer, Priority.ALWAYS);
        Button refreshBtn = secondaryBtn("↺  Refresh");
        HBox toolbar = new HBox(14, search, filterPills, toolSpacer, refreshBtn);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        applyTableStyle();
        table.setStyle(
            "-fx-background-color:" + BG_CARD + ";-fx-control-inner-background:" + BG_CARD + ";" +
            "-fx-table-cell-border-color:transparent;-fx-text-fill:" + TEXT_PRIMARY + ";" +
            "-fx-background-radius:14;-fx-border-color:" + BORDER + ";-fx-border-radius:14;-fx-border-width:1;"
        );
        table.setFixedCellSize(48);
        table.setPlaceholder(new Label("No products found") {{
            setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:14px;");
        }});

        TableColumn<ProductBean, Integer> idCol = new TableColumn<>("#");
        idCol.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getProductId()).asObject());
        idCol.setPrefWidth(50);
        idCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Integer v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); }
                else { setText(String.valueOf(v)); setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:12px;-fx-alignment:center;"); }
            }
        });

        TableColumn<ProductBean, String> nameCol = new TableColumn<>("PRODUCT NAME");
        nameCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
        nameCol.setPrefWidth(200);
        nameCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setGraphic(null); }
                else {
                    Label lbl = new Label(v);
                    lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;-fx-font-weight:bold;");
                    setGraphic(lbl); setText(null);
                }
            }
        });

        TableColumn<ProductBean, Double> costCol = new TableColumn<>("COST ₹");
        costCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getCostPrice()).asObject());
        costCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); }
                else { setText(String.format("%.2f", v)); setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:13px;"); }
            }
        });

        TableColumn<ProductBean, Double> sellCol = new TableColumn<>("SELL ₹");
        sellCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getSellingPrice()).asObject());
        sellCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); }
                else { setText(String.format("%.2f", v)); setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;-fx-font-weight:bold;"); }
            }
        });

        TableColumn<ProductBean, Integer> stockCol = new TableColumn<>("STOCK");
        stockCol.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getStockQuantity()).asObject());
        stockCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Integer v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setGraphic(null); return; }
                String color  = v < 10 ? ACCENT_RED : v < 30 ? ACCENT_AMBER : ACCENT_GREEN;
                String label  = v < 10 ? "Critical" : v < 30 ? "Low" : "Good";
                Label qty   = new Label(String.valueOf(v));
                qty.setStyle("-fx-text-fill:" + color + ";-fx-font-size:13px;-fx-font-weight:bold;");
                Label badge = new Label(label);
                badge.setStyle("-fx-background-color:" + color + "22;-fx-text-fill:" + color + ";" +
                    "-fx-font-size:10px;-fx-padding:2 7;-fx-background-radius:6;-fx-font-weight:bold;");
                HBox cell = new HBox(8, qty, badge);
                cell.setAlignment(Pos.CENTER_LEFT);
                setGraphic(cell); setText(null);
            }
        });

        TableColumn<ProductBean, Double> profitCol = new TableColumn<>("PROFIT ₹");
        profitCol.setCellValueFactory(d ->
            new SimpleDoubleProperty(d.getValue().getSellingPrice() - d.getValue().getCostPrice()).asObject());
        profitCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); }
                else { setText(String.format("%.2f", v));
                    setStyle("-fx-text-fill:" + (v >= 0 ? ACCENT_GREEN : ACCENT_RED) + ";-fx-font-size:13px;-fx-font-weight:bold;"); }
            }
        });

        TableColumn<ProductBean, Double> marginCol = new TableColumn<>("MARGIN %");
        marginCol.setCellValueFactory(d -> {
            double sell = d.getValue().getSellingPrice();
            double cost = d.getValue().getCostPrice();
            double m    = sell == 0 ? 0 : (sell - cost) / sell * 100;
            return new SimpleDoubleProperty(m).asObject();
        });
        marginCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setGraphic(null); return; }
                String color = v >= 25 ? ACCENT_GREEN : v >= 10 ? ACCENT_AMBER : ACCENT_RED;
                Region bg   = new Region(); bg.setPrefHeight(4); bg.setMaxWidth(Double.MAX_VALUE);
                bg.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:2;");
                Region fill = new Region(); fill.setPrefHeight(4);
                fill.setStyle("-fx-background-color:" + color + ";-fx-background-radius:2;");
                StackPane bar = new StackPane(bg, fill);
                StackPane.setAlignment(fill, Pos.CENTER_LEFT);
                double pct = Math.min(v / 100.0, 1.0);
                Platform.runLater(() -> {
                    fill.setPrefWidth(bar.getWidth() * pct);
                    bar.widthProperty().addListener((obs, ov, nv) -> fill.setPrefWidth(nv.doubleValue() * pct));
                });
                Label pctLbl = new Label(String.format("%.1f%%", v));
                pctLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:12px;-fx-font-weight:bold;");
                VBox cell = new VBox(3, pctLbl, bar);
                setGraphic(cell); setText(null);
            }
        });

        TableColumn<ProductBean, Double> stockValCol = new TableColumn<>("STOCK VALUE");
        stockValCol.setCellValueFactory(d ->
            new SimpleDoubleProperty(d.getValue().getSellingPrice() * d.getValue().getStockQuantity()).asObject());
        stockValCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); }
                else { setText("₹ " + String.format("%,.0f", v));
                    setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;"); }
            }
        });

        table.getColumns().setAll(idCol, nameCol, costCol, sellCol, stockCol, profitCol, marginCol, stockValCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        table.setRowFactory(tv -> {
            TableRow<ProductBean> row = new TableRow<>();
            row.setStyle("-fx-background-color:transparent;");
            row.setOnMouseEntered(e -> { if (!row.isEmpty()) row.setStyle("-fx-background-color:" + BG_ELEVATED + ";"); });
            row.setOnMouseExited(e  -> row.setStyle("-fx-background-color:transparent;"));
            return row;
        });

        Runnable[] applyFilter = {null};
        applyFilter[0] = () -> {
            try {
                String q = search.getText().toLowerCase();
                String f = activeFilter[0];
                List<ProductBean> filtered = service.getAllProducts().stream()
                    .filter(p -> p.getName().toLowerCase().contains(q))
                    .filter(p -> {
                        if ("ALL".equals(f))      return true;
                        if ("CRITICAL".equals(f)) return p.getStockQuantity() < 10;
                        if ("WARNING".equals(f))  return p.getStockQuantity() >= 10 && p.getStockQuantity() < 30;
                        if ("HEALTHY".equals(f))  return p.getStockQuantity() >= 30;
                        return true;
                    }).collect(Collectors.toList());
                table.getItems().setAll(filtered);
            } catch (Exception ignored) {}
        };

        search.textProperty().addListener((obs, ov, nv) -> applyFilter[0].run());

        Runnable[] applyRef = applyFilter;
        for (int i = 0; i < pills.length; i++) {
            final String fval = new String[]{"ALL","HEALTHY","WARNING","CRITICAL"}[i];
            final Button pill = pills[i];
            final Button[] otherpills = new Button[pills.length - 1];
            int oi = 0;
            for (Button p : pills) if (p != pill) otherpills[oi++] = p;
            pill.setOnAction(e -> {
                activeFilter[0] = fval;
                setPillActive(pill, otherpills);
                applyRef[0].run();
            });
        }

        TextField name  = styledField("Product name");
        TextField cost  = styledField("Cost price (₹)");
        TextField sell  = styledField("Selling price (₹)");
        TextField stock = styledField("Stock quantity");
        name.setPrefWidth(Double.MAX_VALUE);
        cost.setPrefWidth(Double.MAX_VALUE);
        sell.setPrefWidth(Double.MAX_VALUE);
        stock.setPrefWidth(Double.MAX_VALUE);

        Label profitPreview = new Label("Profit: —");
        profitPreview.setStyle("-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:13px;-fx-font-weight:bold;");
        Label marginPreview = new Label("Margin: —");
        marginPreview.setStyle("-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:12px;");

        Runnable updatePreview = () -> {
            try {
                double c = Double.parseDouble(cost.getText());
                double s = Double.parseDouble(sell.getText());
                double profit = s - c;
                double margin = s == 0 ? 0 : profit / s * 100;
                profitPreview.setText("Profit: ₹ " + String.format("%.2f", profit));
                profitPreview.setStyle("-fx-text-fill:" + (profit >= 0 ? ACCENT_GREEN : ACCENT_RED) + ";-fx-font-size:13px;-fx-font-weight:bold;");
                marginPreview.setText("Margin: " + String.format("%.1f%%", margin));
            } catch (NumberFormatException ignored) {
                profitPreview.setText("Profit: —");
                marginPreview.setText("Margin: —");
            }
        };
        cost.textProperty().addListener((o, ov, nv) -> updatePreview.run());
        sell.textProperty().addListener((o, ov, nv) -> updatePreview.run());

        HBox profitRow = new HBox(16, profitPreview, marginPreview);
        profitRow.setAlignment(Pos.CENTER_LEFT);
        profitRow.setPadding(new Insets(10, 14, 10, 14));
        profitRow.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:10;-fx-border-color:" + BORDER + ";-fx-border-radius:10;-fx-border-width:1;");

        Label formStatus = new Label();
        formStatus.setWrapText(true);
        formStatus.setVisible(false);
        formStatus.setStyle("-fx-font-size:12px;-fx-padding:10 14;-fx-background-radius:8;-fx-border-radius:8;-fx-border-width:1;");

        Label modeLabel = new Label("NEW PRODUCT");
        modeLabel.setStyle("-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:10px;-fx-font-weight:bold;");
        Region modeSpacer = new Region(); HBox.setHgrow(modeSpacer, Priority.ALWAYS);

        Button clearFormBtn = new Button("Clear");
        clearFormBtn.setStyle("-fx-background-color:transparent;-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:12px;-fx-cursor:hand;-fx-padding:4 10;-fx-background-radius:6;");
        clearFormBtn.setOnMouseEntered(e -> clearFormBtn.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;-fx-cursor:hand;-fx-padding:4 10;-fx-background-radius:6;"));
        clearFormBtn.setOnMouseExited(e  -> clearFormBtn.setStyle("-fx-background-color:transparent;-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:12px;-fx-cursor:hand;-fx-padding:4 10;-fx-background-radius:6;"));

        HBox modeRow = new HBox(modeSpacer, modeLabel, clearFormBtn);
        modeRow.setAlignment(Pos.CENTER_LEFT);

        Button addBtn    = primaryBtn("＋  Add Product");
        Button updateBtn = secondaryBtn("↑  Update");
        Button deleteBtn = dangerBtn("✕  Delete");
        addBtn.setPrefWidth(Double.MAX_VALUE); addBtn.setPrefHeight(44);
        updateBtn.setPrefWidth(Double.MAX_VALUE);
        deleteBtn.setPrefWidth(Double.MAX_VALUE);

        HBox actionRow = new HBox(10, updateBtn, deleteBtn);
        HBox.setHgrow(updateBtn, Priority.ALWAYS);
        HBox.setHgrow(deleteBtn, Priority.ALWAYS);

        Separator fSep1 = new Separator(); fSep1.setStyle("-fx-background-color:" + BORDER + ";");
        Separator fSep2 = new Separator(); fSep2.setStyle("-fx-background-color:" + BORDER + ";");

        VBox detailPanel = new VBox(14,
            modeRow,
            sectionLabel("PRODUCT NAME"), name,
            sectionLabel("COST PRICE (₹)"), cost,
            sectionLabel("SELLING PRICE (₹)"), sell,
            profitRow,
            sectionLabel("STOCK QUANTITY"), stock,
            fSep1,
            addBtn,
            actionRow,
            fSep2,
            formStatus
        );
        detailPanel.setPadding(new Insets(22));
        detailPanel.setPrefWidth(300);
        detailPanel.setMinWidth(280);
        detailPanel.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:16;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:16;-fx-border-width:1;"
        );
        detailPanel.setEffect(new DropShadow(20, Color.web("#000000", 0.4)));

        table.setOnMouseClicked(e -> {
            ProductBean p = table.getSelectionModel().getSelectedItem();
            if (p != null) {
                name.setText(p.getName());
                cost.setText(String.valueOf(p.getCostPrice()));
                sell.setText(String.valueOf(p.getSellingPrice()));
                stock.setText(String.valueOf(p.getStockQuantity()));
                modeLabel.setText("EDITING: " + p.getName().toUpperCase());
                modeLabel.setStyle("-fx-text-fill:" + ACCENT_AMBER + ";-fx-font-size:10px;-fx-font-weight:bold;");
                formStatus.setVisible(false);
            }
        });

        clearFormBtn.setOnAction(e -> {
            clearFields(name, cost, sell, stock);
            table.getSelectionModel().clearSelection();
            modeLabel.setText("NEW PRODUCT");
            modeLabel.setStyle("-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:10px;-fx-font-weight:bold;");
            formStatus.setVisible(false);
        });

        Runnable[] showSuccessRef = {null}, showErrRef = {null};
        showSuccessRef[0] = () -> {
            formStatus.setText("✓  Operation completed successfully.");
            formStatus.setStyle("-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:12px;" +
                "-fx-background-color:" + ACCENT_GREEN + "11;-fx-padding:10 14;" +
                "-fx-background-radius:8;-fx-border-color:" + ACCENT_GREEN + "33;-fx-border-radius:8;-fx-border-width:1;");
            formStatus.setOpacity(1); formStatus.setVisible(true);
            PauseTransition p = new PauseTransition(Duration.seconds(3));
            p.setOnFinished(ev -> { FadeTransition ft2 = new FadeTransition(Duration.millis(400), formStatus);
                ft2.setToValue(0); ft2.setOnFinished(ev2 -> { formStatus.setVisible(false); formStatus.setOpacity(1); }); ft2.play(); });
            p.play();
        };
        showErrRef[0] = () -> {
            formStatus.setText("⚠  Please fill all fields correctly.");
            formStatus.setStyle("-fx-text-fill:" + ACCENT_RED + ";-fx-font-size:12px;" +
                "-fx-background-color:" + ACCENT_RED + "11;-fx-padding:10 14;" +
                "-fx-background-radius:8;-fx-border-color:" + ACCENT_RED + "33;-fx-border-radius:8;-fx-border-width:1;");
            formStatus.setOpacity(1); formStatus.setVisible(true);
        };

        Runnable refreshAll = () -> {
            loadProducts();
            applyFilter[0].run();
            updateKpis.run();
        };

        addBtn.setOnAction(e -> {
            try {
                service.addProduct(new ProductBean(name.getText(),
                    Double.parseDouble(cost.getText()),
                    Double.parseDouble(sell.getText()),
                    Integer.parseInt(stock.getText())));
                refreshAll.run();
                clearFields(name, cost, sell, stock);
                modeLabel.setText("NEW PRODUCT");
                modeLabel.setStyle("-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:10px;-fx-font-weight:bold;");
                showSuccessRef[0].run();
                ScaleTransition st = new ScaleTransition(Duration.millis(150), addBtn);
                st.setToX(1.04); st.setToY(1.04); st.setAutoReverse(true); st.setCycleCount(2); st.play();
            } catch (Exception ex) {
                ex.printStackTrace();
                String errMsg = ex.getMessage();
                if (errMsg != null && errMsg.toLowerCase().contains("duplicate")) {
                    formStatus.setText("⚠  A product with this name already exists. Please use a unique name.");
                } else {
                    formStatus.setText("⚠  Please fill all fields correctly.");
                }
                formStatus.setStyle(
                    "-fx-text-fill:" + ACCENT_RED + ";-fx-font-size:12px;" +
                    "-fx-background-color:" + ACCENT_RED + "11;-fx-padding:10 14;" +
                    "-fx-background-radius:8;-fx-border-color:" + ACCENT_RED + "33;" +
                    "-fx-border-radius:8;-fx-border-width:1;"
                );
                formStatus.setOpacity(1);
                formStatus.setVisible(true);
            }
        });

        updateBtn.setOnAction(e -> {
            try {
                ProductBean sel = table.getSelectionModel().getSelectedItem();
                if (sel != null) {
                    sel.setName(name.getText());
                    sel.setCostPrice(Double.parseDouble(cost.getText()));
                    sel.setSellingPrice(Double.parseDouble(sell.getText()));
                    sel.setStockQuantity(Integer.parseInt(stock.getText()));
                    service.updateProduct(sel);
                    refreshAll.run();
                    showSuccessRef[0].run();
                } else { showErrRef[0].run(); }
            } catch (Exception ex) { ex.printStackTrace(); showErrRef[0].run(); }
        });

        deleteBtn.setOnAction(e -> {
            ProductBean sel = table.getSelectionModel().getSelectedItem();
            if (sel != null) {
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                        "Permanently delete \"" + sel.getName() + "\"?", ButtonType.YES, ButtonType.NO);
                confirm.setTitle("Confirm Delete");
                confirm.showAndWait().ifPresent(btn -> {
                    if (btn == ButtonType.YES) {
                        try {
                            service.deleteProduct(sel.getProductId());
                            refreshAll.run();
                            clearFields(name, cost, sell, stock);
                            modeLabel.setText("NEW PRODUCT");
                            modeLabel.setStyle("-fx-text-fill:" + ACCENT_BLUE + ";-fx-font-size:10px;-fx-font-weight:bold;");
                            showSuccessRef[0].run();
                        } catch (Exception ex) { ex.printStackTrace(); }
                    }
                });
            }
        });

        refreshBtn.setOnAction(e -> { refreshAll.run(); });

        loadProducts();
        applyFilter[0].run();

        Label ivLabel = new Label();
        try {
            double tv = service.getAllProducts().stream()
                .mapToDouble(p -> p.getSellingPrice() * p.getStockQuantity()).sum();
            long low = service.getAllProducts().stream().filter(p -> p.getStockQuantity() < 10).count();
            ivLabel.setText("  ▣  Total Inventory Value:  ₹ " + String.format("%,.2f", tv)
                + "      ⚠  " + low + " product(s) below critical stock threshold");
        } catch (Exception ignored) {}
        ivLabel.setStyle(
            "-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:13px;-fx-font-weight:bold;" +
            "-fx-background-color:" + BG_CARD + ";-fx-background-radius:10;" +
            "-fx-border-color:" + ACCENT_GREEN + "22;-fx-border-radius:10;-fx-border-width:1;-fx-padding:12 18;"
        );

        VBox stockHealthCard = buildInvStockHealth();

        VBox.setVgrow(table, Priority.ALWAYS);
        VBox tablePane = new VBox(12, toolbar, table, ivLabel, stockHealthCard);
        HBox.setHgrow(tablePane, Priority.ALWAYS);

        HBox mainLayout = new HBox(20, tablePane, detailPanel);
        VBox.setVgrow(mainLayout, Priority.ALWAYS);

        VBox page = new VBox(22,
            new VBox(4, pageTitle, pageSub),
            invKpiRow,
            mainLayout
        );
        page.setPadding(new Insets(10, 10, 40, 10));
        page.setOpacity(0);
        FadeTransition pageIn = new FadeTransition(Duration.millis(450), page);
        pageIn.setToValue(1); pageIn.play();

        ScrollPane sp = new ScrollPane(page);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background:transparent;-fx-background-color:transparent;");
        return sp;
    }

    private VBox kpiMiniInv(String title, Label valueLbl, String accent, String icon) {
        Label ico = new Label(icon);
        ico.setStyle("-fx-text-fill:" + accent + ";-fx-font-size:16px;");
        Label titleLbl = new Label(title.toUpperCase());
        titleLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");
        Region accentLine = new Region(); accentLine.setPrefHeight(2);
        accentLine.setStyle("-fx-background-color:linear-gradient(to right," + accent + ",transparent);");
        VBox card = new VBox(0, accentLine);
        VBox inner = new VBox(6, new HBox(6, ico, titleLbl), valueLbl);
        inner.setPadding(new Insets(14));
        card.getChildren().add(inner);
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:12;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:12;-fx-border-width:1;");
        card.setEffect(new DropShadow(12, Color.web("#000000", 0.35)));
        return card;
    }

    private Button filterPill(String label, String value, String color) {
        Button b = new Button(label);
        b.setUserData(value);
        b.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-text-fill:" + TEXT_SECONDARY + ";" +
            "-fx-background-radius:20;-fx-border-color:" + BORDER + ";-fx-border-radius:20;" +
            "-fx-border-width:1.5;-fx-font-size:12px;-fx-padding:5 14;-fx-cursor:hand;");
        b.setOnMouseEntered(e -> { if (!b.getStyle().contains(color + ";-fx-text-fill:white"))
            b.setStyle("-fx-background-color:" + color + "22;-fx-text-fill:" + color + ";" +
                "-fx-background-radius:20;-fx-border-color:" + color + ";-fx-border-radius:20;" +
                "-fx-border-width:1.5;-fx-font-size:12px;-fx-padding:5 14;-fx-cursor:hand;"); });
        b.setOnMouseExited(e -> { if (!b.getStyle().contains(color + ";-fx-text-fill:white"))
            b.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-text-fill:" + TEXT_SECONDARY + ";" +
                "-fx-background-radius:20;-fx-border-color:" + BORDER + ";-fx-border-radius:20;" +
                "-fx-border-width:1.5;-fx-font-size:12px;-fx-padding:5 14;-fx-cursor:hand;"); });
        b.getProperties().put("color", color);
        return b;
    }

    private void setPillActive(Button active, Button... others) {
        String color = (String) active.getProperties().get("color");
        if (color == null) color = ACCENT_BLUE;
        active.setStyle("-fx-background-color:" + color + ";-fx-text-fill:white;" +
            "-fx-background-radius:20;-fx-border-color:" + color + ";-fx-border-radius:20;" +
            "-fx-border-width:1.5;-fx-font-size:12px;-fx-padding:5 14;-fx-cursor:hand;-fx-font-weight:bold;");
        for (Button b : others) {
            b.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-text-fill:" + TEXT_SECONDARY + ";" +
                "-fx-background-radius:20;-fx-border-color:" + BORDER + ";-fx-border-radius:20;" +
                "-fx-border-width:1.5;-fx-font-size:12px;-fx-padding:5 14;-fx-cursor:hand;");
        }
    }

    private VBox buildInvStockHealth() {
        Label title = new Label("STOCK HEALTH BREAKDOWN");
        title.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");

        HBox bars = new HBox(20);
        bars.setAlignment(Pos.CENTER_LEFT);

        try {
            List<ProductBean> all = service.getAllProducts();
            int total    = all.size();
            long critical = all.stream().filter(p -> p.getStockQuantity() < 10).count();
            long warning  = all.stream().filter(p -> p.getStockQuantity() >= 10 && p.getStockQuantity() < 30).count();
            long healthy  = all.stream().filter(p -> p.getStockQuantity() >= 30).count();

            bars.getChildren().addAll(
                stockMiniBar("Critical", critical, total, ACCENT_RED),
                stockMiniBar("Warning",  warning,  total, ACCENT_AMBER),
                stockMiniBar("Healthy",  healthy,  total, ACCENT_GREEN)
            );
        } catch (Exception ignored) {}

        HBox content = new HBox(24, title, bars);
        content.setAlignment(Pos.CENTER_LEFT);
        content.setPadding(new Insets(14, 18, 14, 18));
        content.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:12;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:12;-fx-border-width:1;");
        content.setEffect(new DropShadow(10, Color.web("#000000", 0.3)));

        VBox wrapper = new VBox(content);
        return wrapper;
    }

    private HBox stockMiniBar(String label, long count, int total, String color) {
        Label nameLbl  = new Label(label);
        nameLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:11px;");
        Label countLbl = new Label(String.valueOf(count));
        countLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:13px;-fx-font-weight:bold;");

        Region bg   = new Region(); bg.setPrefHeight(6); bg.setPrefWidth(120);
        bg.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:3;");
        Region fill = new Region(); fill.setPrefHeight(6);
        fill.setStyle("-fx-background-color:" + color + ";-fx-background-radius:3;");
        StackPane bar = new StackPane(bg, fill);
        StackPane.setAlignment(fill, Pos.CENTER_LEFT);
        double pct = total == 0 ? 0 : (double) count / total;
        Platform.runLater(() -> {
            fill.setPrefWidth(120 * pct);
        });

        VBox col = new VBox(4, new HBox(8, nameLbl, countLbl), bar);
        HBox wrapper = new HBox(col);
        return wrapper;
    }

    // ─── SALES (MODERNIZED) ───────────────────────────────────────────────────

    private ScrollPane createSalesPane() {

        Label clockLbl = new Label();
        clockLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:12px;");
        Timeline clockTl = new Timeline(new KeyFrame(Duration.seconds(1),
                e -> clockLbl.setText(java.time.LocalTime.now().withNano(0).toString())));
        clockTl.setCycleCount(Timeline.INDEFINITE);
        clockTl.play();

        Label pageTitle = headingLabel("Sales Terminal");
        Label pageSub   = makeSub("Record transactions, monitor live totals, and track recent activity");
        Region hSpacer  = new Region();
        HBox.setHgrow(hSpacer, Priority.ALWAYS);
        HBox pageHeader = new HBox(16, new VBox(4, pageTitle, pageSub), hSpacer, clockLbl);
        pageHeader.setAlignment(Pos.CENTER_LEFT);

        ProductBean[] selectedProduct = {null};
        javafx.scene.Node[] activeTile = {null};
        int[] qty = {1};
        double[] sessionRevenue = {0};
        int[]    sessionCount   = {0};

        Label pickTitle = new Label("SELECT PRODUCT");
        pickTitle.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");

        TextField productSearch = styledField("🔍  Search products...");

        FlowPane productGrid = new FlowPane();
        productGrid.setHgap(10);
        productGrid.setVgap(10);
        productGrid.setPrefWrapLength(560);

        Label qtyTitle = new Label("QUANTITY");
        qtyTitle.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");

        Label qtyDisplay = new Label("1");
        qtyDisplay.setStyle(
            "-fx-text-fill:" + TEXT_PRIMARY + ";" +
            "-fx-font-size:32px;-fx-font-weight:bold;-fx-min-width:50;-fx-alignment:center;"
        );

        Button qtyMinus = new Button("−");
        qtyMinus.setStyle(
            "-fx-background-color:" + BG_ELEVATED + ";-fx-text-fill:" + TEXT_PRIMARY + ";" +
            "-fx-font-size:20px;-fx-background-radius:10;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:10;-fx-border-width:1.5;-fx-padding:6 18;-fx-cursor:hand;"
        );
        Button qtyPlus = new Button("+");
        qtyPlus.setStyle(
            "-fx-background-color:" + BG_ELEVATED + ";-fx-text-fill:" + TEXT_PRIMARY + ";" +
            "-fx-font-size:20px;-fx-background-radius:10;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:10;-fx-border-width:1.5;-fx-padding:6 18;-fx-cursor:hand;"
        );

        Label summaryTitle   = new Label("ORDER SUMMARY");
        summaryTitle.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");
        Label summaryProduct = new Label("No product selected");
        summaryProduct.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:14px;");
        Label summaryPrice   = new Label("₹ —");
        summaryPrice.setStyle("-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:22px;-fx-font-weight:bold;");
        Label summaryStock   = new Label("");
        summaryStock.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:12px;");

        Runnable updateSummary = () -> {
            if (selectedProduct[0] != null) {
                double total = selectedProduct[0].getSellingPrice() * qty[0];
                summaryProduct.setText(selectedProduct[0].getName() + "  ×  " + qty[0]);
                summaryPrice.setText("₹ " + String.format("%,.2f", total));
                summaryStock.setText(selectedProduct[0].getStockQuantity() + " units available");
            } else {
                summaryProduct.setText("No product selected");
                summaryPrice.setText("₹ —");
                summaryStock.setText("");
            }
        };

        qtyMinus.setOnAction(e -> {
            if (qty[0] > 1) { qty[0]--; qtyDisplay.setText(String.valueOf(qty[0])); updateSummary.run(); }
        });
        qtyPlus.setOnAction(e -> {
            if (selectedProduct[0] == null || qty[0] < selectedProduct[0].getStockQuantity()) {
                qty[0]++; qtyDisplay.setText(String.valueOf(qty[0])); updateSummary.run();
            }
        });

        HBox qtyStepper = new HBox(16, qtyMinus, qtyDisplay, qtyPlus);
        qtyStepper.setAlignment(Pos.CENTER_LEFT);

        Button recordBtn = primaryBtn("⬡  Confirm Sale");
        recordBtn.setPrefWidth(Double.MAX_VALUE);
        recordBtn.setPrefHeight(50);

        Label resultBanner = new Label();
        resultBanner.setWrapText(true);
        resultBanner.setVisible(false);

        Label sessionRevLbl   = new Label("₹ 0.00");
        sessionRevLbl.setStyle("-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:22px;-fx-font-weight:bold;");
        Label sessionCountLbl = new Label("0");
        sessionCountLbl.setStyle("-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:22px;-fx-font-weight:bold;");
        Label sessionAvgLbl   = new Label("₹ 0.00");
        sessionAvgLbl.setStyle("-fx-text-fill:" + ACCENT_AMBER + ";-fx-font-size:22px;-fx-font-weight:bold;");

        VBox kpi1 = kpiMiniSales("Session Revenue",    sessionRevLbl,   ACCENT_CYAN,   "◈");
        VBox kpi2 = kpiMiniSales("Sales Recorded",     sessionCountLbl, ACCENT_GREEN,  "✓");
        VBox kpi3 = kpiMiniSales("Average Sale Value", sessionAvgLbl,   ACCENT_AMBER,  "⊛");
        HBox.setHgrow(kpi1, Priority.ALWAYS);
        HBox.setHgrow(kpi2, Priority.ALWAYS);
        HBox.setHgrow(kpi3, Priority.ALWAYS);
        HBox kpiStrip = new HBox(14, kpi1, kpi2, kpi3);

        Label feedTitle = new Label("RECENT TRANSACTIONS");
        feedTitle.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");

        VBox transactionFeed = new VBox(8);
        transactionFeed.setPadding(new Insets(18));
        transactionFeed.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:14;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:14;-fx-border-width:1;"
        );
        transactionFeed.setEffect(new DropShadow(18, Color.web("#000000", 0.4)));

        Label emptyFeed = new Label("No transactions this session");
        emptyFeed.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:13px;");
        transactionFeed.getChildren().addAll(feedTitle, emptyFeed);

        Label spotTitle = new Label("QUICK INVENTORY SNAPSHOT");
        spotTitle.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");

        VBox snapshotRows = new VBox(0);
        try {
            service.getAllProducts().stream().limit(6).forEach(p ->
                snapshotRows.getChildren().add(buildSnapshotRow(p)));
        } catch (Exception ignored) {}

        VBox snapshotCard = new VBox(12, spotTitle, snapshotRows);
        snapshotCard.setPadding(new Insets(18));
        snapshotCard.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:14;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:14;-fx-border-width:1;"
        );
        snapshotCard.setEffect(new DropShadow(18, Color.web("#000000", 0.4)));

        VBox rightPane = new VBox(18, kpiStrip, transactionFeed, snapshotCard);
        HBox.setHgrow(rightPane, Priority.ALWAYS);

        Runnable[] rebuildGrid = {null};
        rebuildGrid[0] = () -> {
            productGrid.getChildren().clear();
            activeTile[0] = null;
            try {
                String filter = productSearch.getText().toLowerCase();
                service.getAllProducts().stream()
                    .filter(p -> p.getName().toLowerCase().contains(filter))
                    .forEach(p -> {
                        VBox tile = buildProductTile(p);
                        tile.setOnMouseClicked(e -> {
                            if (activeTile[0] != null) activeTile[0].setStyle(tileStyle(false));
                            selectedProduct[0] = p;
                            activeTile[0] = tile;
                            tile.setStyle(tileStyle(true));
                            qty[0] = 1;
                            qtyDisplay.setText("1");
                            updateSummary.run();
                        });
                        productGrid.getChildren().add(tile);
                    });
            } catch (Exception ignored) {}
        };
        rebuildGrid[0].run();
        productSearch.textProperty().addListener((obs, ov, nv) -> rebuildGrid[0].run());

        Separator formSep1 = new Separator(); formSep1.setStyle("-fx-background-color:" + BORDER + ";");
        Separator formSep2 = new Separator(); formSep2.setStyle("-fx-background-color:" + BORDER + ";");
        Separator formSep3 = new Separator(); formSep3.setStyle("-fx-background-color:" + BORDER + ";");

        VBox formCard = new VBox(18,
            pickTitle, productSearch, productGrid,
            formSep1, qtyTitle, qtyStepper,
            formSep2, summaryTitle, new VBox(4, summaryProduct, summaryPrice, summaryStock),
            formSep3, recordBtn, resultBanner
        );
        formCard.setPadding(new Insets(28));
        formCard.setPrefWidth(420);
        formCard.setStyle(
            "-fx-background-color:" + BG_CARD + ";" +
            "-fx-background-radius:18;-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:18;-fx-border-width:1;"
        );
        formCard.setEffect(new DropShadow(24, Color.web("#000000", 0.45)));

        Runnable[] rebuildRef = rebuildGrid;
        recordBtn.setOnAction(e -> {
            if (selectedProduct[0] == null) {
                resultBanner.setText("⚠  Please select a product first.");
                resultBanner.setStyle("-fx-text-fill:" + ACCENT_RED + ";-fx-font-size:13px;" +
                    "-fx-background-color:" + ACCENT_RED + "11;-fx-padding:12 16;" +
                    "-fx-background-radius:10;-fx-border-color:" + ACCENT_RED + "33;-fx-border-radius:10;-fx-border-width:1;");
                resultBanner.setOpacity(1); resultBanner.setVisible(true);
                return;
            }
            try {
                ProductBean sel = selectedProduct[0];
                int q = qty[0];
                double total = sel.getSellingPrice() * q;

                SalesBean sale = new SalesBean();
                sale.setProductId(sel.getProductId());
                sale.setQuantity(q);
                sale.setDate(LocalDate.now());
                sale.setTotalAmount(total);
                service.addSale(sale);

                sessionRevenue[0] += total;
                sessionCount[0]++;
                sessionRevLbl.setText("₹ " + String.format("%,.2f", sessionRevenue[0]));
                sessionCountLbl.setText(String.valueOf(sessionCount[0]));
                sessionAvgLbl.setText("₹ " + String.format("%,.2f", sessionRevenue[0] / sessionCount[0]));
                flashNode(sessionRevLbl);
                flashNode(sessionCountLbl);

                HBox feedRow = buildTransactionRow(sel.getName(), q, total, sessionCount[0]);
                feedRow.setOpacity(0);
                if (transactionFeed.getChildren().contains(emptyFeed))
                    transactionFeed.getChildren().remove(emptyFeed);
                transactionFeed.getChildren().add(1, feedRow);
                if (transactionFeed.getChildren().size() > 9)
                    transactionFeed.getChildren().remove(9);
                FadeTransition fadein = new FadeTransition(Duration.millis(350), feedRow);
                fadein.setToValue(1); fadein.play();

                resultBanner.setText("✓  Sale recorded — " + sel.getName() + " × " + q + "  →  ₹ " + String.format("%,.2f", total));
                resultBanner.setStyle("-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:13px;" +
                    "-fx-background-color:" + ACCENT_GREEN + "11;-fx-padding:12 16;" +
                    "-fx-background-radius:10;-fx-border-color:" + ACCENT_GREEN + "33;-fx-border-radius:10;-fx-border-width:1;");
                resultBanner.setOpacity(1); resultBanner.setVisible(true);

                PauseTransition pause = new PauseTransition(Duration.seconds(3));
                pause.setOnFinished(ev -> {
                    FadeTransition ft2 = new FadeTransition(Duration.millis(400), resultBanner);
                    ft2.setToValue(0);
                    ft2.setOnFinished(ev2 -> { resultBanner.setVisible(false); resultBanner.setOpacity(1); });
                    ft2.play();
                });
                pause.play();

                qty[0] = 1; qtyDisplay.setText("1");
                selectedProduct[0] = null; activeTile[0] = null;
                updateSummary.run();
                rebuildRef[0].run();

            } catch (Exception ex) {
                ex.printStackTrace();
                resultBanner.setText("⚠  Error recording sale. Check connection.");
                resultBanner.setStyle("-fx-text-fill:" + ACCENT_RED + ";-fx-font-size:13px;" +
                    "-fx-background-color:" + ACCENT_RED + "11;-fx-padding:12 16;" +
                    "-fx-background-radius:10;-fx-border-color:" + ACCENT_RED + "33;-fx-border-radius:10;-fx-border-width:1;");
                resultBanner.setOpacity(1); resultBanner.setVisible(true);
            }
        });

        HBox mainLayout = new HBox(24, formCard, rightPane);

        VBox page = new VBox(24, pageHeader, mainLayout);
        page.setPadding(new Insets(10, 10, 40, 10));
        page.setOpacity(0);
        FadeTransition pageIn = new FadeTransition(Duration.millis(500), page);
        pageIn.setToValue(1); pageIn.play();

        ScrollPane sp = new ScrollPane(page);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background:transparent;-fx-background-color:transparent;");
        return sp;
    }

    private VBox buildProductTile(ProductBean p) {
        String stockColor = p.getStockQuantity() < 10 ? ACCENT_RED
                          : p.getStockQuantity() < 30 ? ACCENT_AMBER : ACCENT_GREEN;
        Label nameLbl = new Label(p.getName());
        nameLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;-fx-font-weight:bold;-fx-wrap-text:true;");
        nameLbl.setWrapText(true); nameLbl.setMaxWidth(130);
        Label priceLbl = new Label("₹ " + String.format("%.0f", p.getSellingPrice()));
        priceLbl.setStyle("-fx-text-fill:" + ACCENT_CYAN + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label stockLbl = new Label(p.getStockQuantity() + " in stock");
        stockLbl.setStyle("-fx-text-fill:" + stockColor + ";-fx-font-size:11px;");
        Region accentTop = new Region(); accentTop.setPrefHeight(3);
        accentTop.setStyle("-fx-background-color:linear-gradient(to right," + stockColor + ",transparent);-fx-background-radius:14 14 0 0;");
        VBox inner = new VBox(6, nameLbl, priceLbl, stockLbl);
        inner.setPadding(new Insets(12, 14, 14, 14));
        VBox tile = new VBox(0, accentTop, inner);
        tile.setPrefWidth(155);
        tile.setStyle(tileStyle(false));
        tile.setEffect(new DropShadow(10, Color.web("#000000", 0.3)));
        tile.setOnMouseEntered(ev -> { if (!tile.getStyle().contains(ACCENT_BLUE)) tile.setOpacity(0.82); });
        tile.setOnMouseExited(ev  -> tile.setOpacity(1.0));
        return tile;
    }

    private String tileStyle(boolean active) {
        return active
            ? "-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:14;" +
              "-fx-border-color:" + ACCENT_BLUE + ";-fx-border-radius:14;-fx-border-width:2;-fx-cursor:hand;"
            : "-fx-background-color:" + BG_SURFACE + ";-fx-background-radius:14;" +
              "-fx-border-color:" + BORDER + ";-fx-border-radius:14;-fx-border-width:1.5;-fx-cursor:hand;";
    }

    private VBox kpiMiniSales(String title, Label valueLbl, String accent, String icon) {
        Label ico = new Label(icon);
        ico.setStyle("-fx-text-fill:" + accent + ";-fx-font-size:16px;");
        Label titleLbl = new Label(title.toUpperCase());
        titleLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");
        Region accentLine = new Region(); accentLine.setPrefHeight(2);
        accentLine.setStyle("-fx-background-color:linear-gradient(to right," + accent + ",transparent);");
        VBox card = new VBox(0, accentLine);
        VBox inner = new VBox(6, new HBox(6, ico, titleLbl), valueLbl);
        inner.setPadding(new Insets(14));
        card.getChildren().add(inner);
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:12;" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:12;-fx-border-width:1;");
        card.setEffect(new DropShadow(12, Color.web("#000000", 0.35)));
        return card;
    }

    private HBox buildTransactionRow(String name, int qty, double total, int idx) {
        Label idxLbl  = new Label("#" + idx);
        idxLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:11px;-fx-min-width:28;");
        Label nameLbl = new Label(name);
        nameLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;");
        Label qtyLbl  = new Label("×" + qty);
        qtyLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;" +
            "-fx-padding:2 8;-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:6;");
        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
        Label totalLbl = new Label("₹ " + String.format("%,.2f", total));
        totalLbl.setStyle("-fx-text-fill:" + ACCENT_GREEN + ";-fx-font-size:13px;-fx-font-weight:bold;");
        Label timeLbl  = new Label(java.time.LocalTime.now().withNano(0).toString());
        timeLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:11px;");
        HBox row = new HBox(10, idxLbl, nameLbl, qtyLbl, sp, totalLbl, timeLbl);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(8, 4, 8, 4));
        row.setStyle("-fx-border-color:transparent transparent " + BORDER + " transparent;-fx-border-width:1;");
        return row;
    }

    private HBox buildSnapshotRow(ProductBean p) {
        String stockColor = p.getStockQuantity() < 10 ? ACCENT_RED
                          : p.getStockQuantity() < 30 ? ACCENT_AMBER : ACCENT_GREEN;
        Label nameLbl = new Label(p.getName());
        nameLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;");
        nameLbl.setMaxWidth(180);
        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
        Label priceLbl = new Label("₹" + String.format("%.0f", p.getSellingPrice()));
        priceLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        Label stockLbl = new Label(String.valueOf(p.getStockQuantity()));
        stockLbl.setStyle("-fx-text-fill:" + stockColor + ";-fx-font-weight:bold;" +
            "-fx-font-size:12px;-fx-min-width:30;-fx-alignment:center-right;");
        HBox row = new HBox(10, nameLbl, sp, priceLbl, stockLbl);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(9, 4, 9, 4));
        String baseStyle = "-fx-border-color:transparent transparent " + BORDER + " transparent;-fx-border-width:1;-fx-cursor:hand;";
        row.setStyle(baseStyle);
        row.setOnMouseEntered(e -> row.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:8;-fx-cursor:hand;"));
        row.setOnMouseExited(e  -> row.setStyle(baseStyle));
        return row;
    }

    private void flashNode(javafx.scene.Node node) {
        ScaleTransition st = new ScaleTransition(Duration.millis(180), node);
        st.setToX(1.15); st.setToY(1.15);
        st.setAutoReverse(true); st.setCycleCount(2);
        st.play();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── ANALYTICS ────────────────────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    private StackPane createAnalyticsPane() {
        StackPane rootStack = new StackPane();
        VBox content = new VBox(24);
        content.setPadding(new Insets(10, 10, 40, 10));

        Label pageTitle = headingLabel("Analytics  /  ERP Intelligence");
        Label pageSub   = makeSub("Real-time insights across revenue, inventory, and sales performance");

        Button aiBtn = new Button();
        Label aiIcon = new Label("◎");
        aiIcon.setStyle("-fx-font-size:22px;-fx-text-fill:" + ACCENT_PURPLE + ";");
        Label aiLabel = new Label("AI Insights");
        aiLabel.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;-fx-font-weight:bold;");
        VBox aiBtnInner = new VBox(2, aiIcon, aiLabel);
        aiBtnInner.setAlignment(Pos.CENTER);
        aiBtn.setGraphic(aiBtnInner);
        aiBtn.setStyle("-fx-background-color:" + ACCENT_PURPLE + "18;-fx-border-color:" + ACCENT_PURPLE + "55;" +
            "-fx-border-width:1.5;-fx-border-radius:14;-fx-background-radius:14;-fx-padding:10 18;-fx-cursor:hand;");
        aiBtn.setOnMouseEntered(e -> aiBtn.setStyle("-fx-background-color:" + ACCENT_PURPLE + "30;-fx-border-color:" + ACCENT_PURPLE + ";-fx-border-width:1.5;-fx-border-radius:14;-fx-background-radius:14;-fx-padding:10 18;-fx-cursor:hand;"));
        aiBtn.setOnMouseExited(e  -> aiBtn.setStyle("-fx-background-color:" + ACCENT_PURPLE + "18;-fx-border-color:" + ACCENT_PURPLE + "55;-fx-border-width:1.5;-fx-border-radius:14;-fx-background-radius:14;-fx-padding:10 18;-fx-cursor:hand;"));
        ScaleTransition pulse = new ScaleTransition(Duration.millis(1200), aiIcon);
        pulse.setFromX(1.0); pulse.setToX(1.18); pulse.setFromY(1.0); pulse.setToY(1.18);
        pulse.setAutoReverse(true); pulse.setCycleCount(Animation.INDEFINITE); pulse.play();

        Region hspacer = new Region(); HBox.setHgrow(hspacer, Priority.ALWAYS);
        HBox headerRow = new HBox(16, new VBox(4, pageTitle, pageSub), hspacer, aiBtn);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        HBox kpiRow = new HBox(16);
        try {
            Map<String, Double> rev  = service.getMonthlyRevenue();
            Map<String, Double> pred = service.getSalesPredictionInsights();
            List<ProductBean>   prods = service.getAllProducts();
            Map<String, Integer> topSelling = service.getTopSellingProducts();
            double totalRevenue   = rev.values().stream().mapToDouble(Double::doubleValue).sum();
            long   lowStock       = prods.stream().filter(p -> p.getStockQuantity() < 10).count();
            double totalInvVal    = prods.stream().mapToDouble(p -> p.getSellingPrice() * p.getStockQuantity()).sum();
            int    totalUnitsSold = topSelling.values().stream().mapToInt(Integer::intValue).sum();
            kpiRow.getChildren().addAll(
                miniKpi("Total Revenue",   "₹ " + compactNum(totalRevenue),    ACCENT_CYAN,   "◈"),
                miniKpi("Low Stock Items", String.valueOf(lowStock) + " items", ACCENT_RED,    "⚠"),
                miniKpi("Inventory Value", "₹ " + compactNum(totalInvVal),     ACCENT_GREEN,  "▣"),
                miniKpi("Units Sold",      String.valueOf(totalUnitsSold),      ACCENT_AMBER,  "⊛"),
                miniKpi("Avg Monthly Rev", "₹ " + compactNum(rev.isEmpty() ? 0 : totalRevenue / rev.size()), ACCENT_PURPLE, "◉")
            );
            for (javafx.scene.Node n : kpiRow.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);
        } catch (Exception e) { e.printStackTrace(); }

        HBox row1 = new HBox(20); HBox.setHgrow(row1, Priority.ALWAYS);
        VBox lineChartCard = buildRevenueLineChart(); HBox.setHgrow(lineChartCard, Priority.ALWAYS);
        VBox barChartCard  = buildTopSellingBarChart(); barChartCard.setPrefWidth(360);
        row1.getChildren().addAll(lineChartCard, barChartCard);

        HBox row2 = new HBox(20);
        VBox monthlyBarCard = buildMonthlyRevenueBarChart(); HBox.setHgrow(monthlyBarCard, Priority.ALWAYS);
        VBox stockHealthCard = buildStockHealthPanel(); stockHealthCard.setPrefWidth(340);
        row2.getChildren().addAll(monthlyBarCard, stockHealthCard);

        VBox profitCard = buildProfitMarginTable();
        content.getChildren().addAll(headerRow, kpiRow, row1, row2, profitCard);

        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background:transparent;-fx-background-color:transparent;");
        rootStack.getChildren().add(sp);
        aiBtn.setOnAction(e -> showAiPanel(rootStack));
        return rootStack;
    }

    private VBox miniKpi(String title, String value, String accent, String icon) {
        Label ico = new Label(icon);
        ico.setStyle("-fx-text-fill:" + accent + ";-fx-font-size:18px;");
        Label titleLbl = new Label(title);
        titleLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:11px;");
        Label valueLbl = new Label(value);
        valueLbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:16px;-fx-font-weight:bold;");
        Region accentLine = new Region(); accentLine.setPrefHeight(2);
        accentLine.setStyle("-fx-background-color:linear-gradient(to right," + accent + ",transparent);");
        VBox card = new VBox(0, accentLine);
        VBox inner = new VBox(8, new HBox(8, ico, titleLbl), valueLbl);
        inner.setPadding(new Insets(14));
        card.getChildren().add(inner);
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:12;-fx-border-color:" + BORDER + ";-fx-border-radius:12;-fx-border-width:1;");
        card.setEffect(new DropShadow(12, Color.web("#000000", 0.35)));
        return card;
    }

    private VBox buildRevenueLineChart() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        xAxis.setStyle("-fx-tick-label-fill:" + TEXT_SECONDARY + ";");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        LineChart<String, Number> chart = new LineChart<>(xAxis, yAxis);
        chart.setTitle(null); chart.setCreateSymbols(true); chart.setAnimated(true);
        chart.setPrefHeight(280); chart.setLegendVisible(false);
        chart.setStyle("-fx-background-color:transparent;");
        try {
            Map<String, Double> revenue = service.getMonthlyRevenue();
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Revenue");
            for (String m : revenue.keySet().stream().sorted().toList())
                series.getData().add(new XYChart.Data<>(m, revenue.get(m)));
            chart.getData().add(series);
        } catch (Exception e) { e.printStackTrace(); }
        Platform.runLater(() -> {
            try {
                chart.lookup(".chart-plot-background").setStyle("-fx-background-color:" + BG_ELEVATED + ";");
                chart.lookupAll(".chart-series-line").forEach(n -> n.setStyle("-fx-stroke:" + ACCENT_CYAN + ";-fx-stroke-width:2.5;"));
                chart.lookupAll(".chart-line-symbol").forEach(n -> n.setStyle("-fx-background-color:" + ACCENT_CYAN + "," + BG_CARD + ";"));
            } catch (Exception ignored) {}
        });
        Label lbl = new Label("Revenue Trend");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Monthly revenue performance");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        VBox card = new VBox(10, new VBox(2, lbl, sub), chart);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(16, Color.web("#000000", 0.4)));
        return card;
    }

    private VBox buildTopSellingBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        xAxis.setTickLabelRotation(-35);
        NumberAxis yAxis = new NumberAxis();
        yAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setTitle(null); chart.setAnimated(true); chart.setPrefHeight(280);
        chart.setLegendVisible(false); chart.setCategoryGap(18); chart.setBarGap(4);
        chart.setStyle("-fx-background-color:transparent;");
        try {
            Map<String, Integer> top = service.getTopSellingProducts();
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            top.entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed()).limit(6)
                .forEach(en -> series.getData().add(new XYChart.Data<>(
                    en.getKey().length() > 10 ? en.getKey().substring(0,10) + "…" : en.getKey(), en.getValue())));
            chart.getData().add(series);
        } catch (Exception e) { e.printStackTrace(); }
        Platform.runLater(() -> {
            try {
                chart.lookup(".chart-plot-background").setStyle("-fx-background-color:" + BG_ELEVATED + ";");
                String[] colors = {ACCENT_BLUE, ACCENT_CYAN, ACCENT_GREEN, ACCENT_AMBER, ACCENT_RED, ACCENT_PURPLE};
                int[] i = {0};
                chart.lookupAll(".data0.chart-bar,.data1.chart-bar,.data2.chart-bar,.data3.chart-bar,.data4.chart-bar,.data5.chart-bar")
                    .forEach(n -> { n.setStyle("-fx-bar-fill:" + colors[i[0] % colors.length] + ";"); i[0]++; });
            } catch (Exception ignored) {}
        });
        Label lbl = new Label("Top Selling Products");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Units sold per product");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        VBox card = new VBox(10, new VBox(2, lbl, sub), chart);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(16, Color.web("#000000", 0.4)));
        return card;
    }

    private VBox buildMonthlyRevenueBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        NumberAxis yAxis = new NumberAxis();
        yAxis.setTickLabelFill(Color.web(TEXT_SECONDARY));
        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setTitle(null); chart.setAnimated(true); chart.setPrefHeight(260);
        chart.setLegendVisible(false); chart.setStyle("-fx-background-color:transparent;");
        try {
            Map<String, Double> revenue = service.getMonthlyRevenue();
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Revenue");
            for (String m : revenue.keySet().stream().sorted().toList())
                series.getData().add(new XYChart.Data<>(m, revenue.get(m)));
            chart.getData().add(series);
        } catch (Exception e) { e.printStackTrace(); }
        Platform.runLater(() -> {
            try {
                chart.lookup(".chart-plot-background").setStyle("-fx-background-color:" + BG_ELEVATED + ";");
                chart.lookupAll(".default-color0.chart-bar").forEach(n ->
                    n.setStyle("-fx-bar-fill:linear-gradient(to top," + ACCENT_BLUE + "," + ACCENT_CYAN + ");"));
            } catch (Exception ignored) {}
        });
        Label lbl = new Label("Monthly Revenue Breakdown");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Revenue distributed across months");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        VBox card = new VBox(10, new VBox(2, lbl, sub), chart);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(16, Color.web("#000000", 0.4)));
        return card;
    }

    private VBox buildStockHealthPanel() {
        Label lbl = new Label("Stock Health Monitor");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Inventory alert breakdown");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        VBox rows = new VBox(10);
        try {
            List<ProductBean> prods = service.getAllProducts();
            long critical = prods.stream().filter(p -> p.getStockQuantity() < 10).count();
            long warning  = prods.stream().filter(p -> p.getStockQuantity() >= 10 && p.getStockQuantity() < 30).count();
            long healthy  = prods.stream().filter(p -> p.getStockQuantity() >= 30).count();
            int  total    = prods.size();
            rows.getChildren().addAll(
                stockRow("Critical ( < 10 )",  critical, total, ACCENT_RED),
                stockRow("Warning  ( 10–29 )",  warning,  total, ACCENT_AMBER),
                stockRow("Healthy  ( ≥ 30 )",   healthy,  total, ACCENT_GREEN)
            );
            Label lowLbl = new Label("LOW STOCK ITEMS");
            lowLbl.setStyle("-fx-text-fill:" + TEXT_MUTED + ";-fx-font-size:10px;-fx-font-weight:bold;");
            VBox lowList = new VBox(6);
            service.getLowStockProducts().stream().limit(5).forEach(p -> {
                HBox row = new HBox();
                Label nm = new Label(p.getName());
                nm.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:12px;");
                Region sp2 = new Region(); HBox.setHgrow(sp2, Priority.ALWAYS);
                Label qty = new Label(p.getStockQuantity() + " left");
                qty.setStyle("-fx-text-fill:" + ACCENT_RED + ";-fx-font-size:12px;-fx-font-weight:bold;");
                row.getChildren().addAll(nm, sp2, qty);
                lowList.getChildren().add(row);
            });
            rows.getChildren().addAll(new Separator() {{ setStyle("-fx-background-color:" + BORDER + ";"); }}, lowLbl, lowList);
        } catch (Exception e) { e.printStackTrace(); }
        VBox card = new VBox(14, new VBox(2, lbl, sub), rows);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(16, Color.web("#000000", 0.4)));
        return card;
    }

    private VBox stockRow(String label, long count, int total, String color) {
        Label nameLbl  = new Label(label);
        nameLbl.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        double pct = total == 0 ? 0 : (double) count / total;
        return new VBox(4, nameLbl, makeProgressBar(pct, color));
    }

    private StackPane makeProgressBar(double pct, String color) {
        Region bg   = new Region(); bg.setPrefHeight(6); bg.setPrefWidth(Double.MAX_VALUE);
        bg.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:3;");
        Region fill = new Region(); fill.setPrefHeight(6);
        fill.setStyle("-fx-background-color:" + color + ";-fx-background-radius:3;");
        StackPane bar = new StackPane(bg, fill);
        StackPane.setAlignment(fill, Pos.CENTER_LEFT);
        Platform.runLater(() -> {
            double maxW = bar.getWidth() > 0 ? bar.getWidth() : 240;
            fill.setPrefWidth(maxW * pct);
            bar.widthProperty().addListener((obs, ov, nv) -> fill.setPrefWidth(nv.doubleValue() * pct));
        });
        return bar;
    }

    private VBox buildProfitMarginTable() {
        Label lbl = new Label("Profit Margin Analysis");
        lbl.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:14px;-fx-font-weight:bold;");
        Label sub = new Label("Per-product cost vs. selling breakdown");
        sub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        TableView<ProductBean> pmTable = new TableView<>();
        pmTable.setPrefHeight(220);
        pmTable.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-control-inner-background:" + BG_ELEVATED + ";-fx-table-cell-border-color:transparent;-fx-text-fill:" + TEXT_PRIMARY + ";");
        TableColumn<ProductBean, String>  nameCol = new TableColumn<>("Product");
        nameCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName())); nameCol.setPrefWidth(200);
        TableColumn<ProductBean, Double> costCol = new TableColumn<>("Cost (₹)");
        costCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getCostPrice()).asObject());
        costCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("%.2f", v));
                setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";");
            }
        });
        TableColumn<ProductBean, Double> sellCol = new TableColumn<>("Sell (₹)");
        sellCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getSellingPrice()).asObject());
        sellCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("%.2f", v));
                setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";");
            }
        });
        TableColumn<ProductBean, Double> profitCol = new TableColumn<>("Profit (₹)");
        profitCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getSellingPrice() - d.getValue().getCostPrice()).asObject());
        profitCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("%.2f", v));
                setStyle("-fx-text-fill:" + (v != null && v >= 0 ? ACCENT_GREEN : ACCENT_RED) + ";-fx-font-weight:bold;");
            }
        });
        TableColumn<ProductBean, Double> marginCol = new TableColumn<>("Margin %");
        marginCol.setCellValueFactory(d -> {
            double cost = d.getValue().getCostPrice(); double sell = d.getValue().getSellingPrice();
            return new SimpleDoubleProperty(cost == 0 ? 0 : ((sell - cost) / sell) * 100).asObject();
        });
        marginCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setGraphic(null); return; }
                setText(String.format("%.1f%%", v));
                setStyle("-fx-text-fill:" + (v >= 20 ? ACCENT_GREEN : v >= 10 ? ACCENT_AMBER : ACCENT_RED) + ";-fx-font-weight:bold;");
            }
        });
        pmTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        pmTable.getColumns().addAll(nameCol, costCol, sellCol, profitCol, marginCol);
        try { pmTable.getItems().addAll(service.getAllProducts()); } catch (Exception e) { e.printStackTrace(); }
        VBox card = new VBox(12, new VBox(2, lbl, sub), pmTable);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color:" + BG_CARD + ";-fx-background-radius:16;-fx-border-color:" + BORDER + ";-fx-border-radius:16;-fx-border-width:1;");
        card.setEffect(new DropShadow(16, Color.web("#000000", 0.4)));
        return card;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── AI FLOATING PANEL ────────────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    private void showAiPanel(StackPane parentStack) {
        if (aiPanelOverlay != null) {
            parentStack.getChildren().remove(aiPanelOverlay);
            aiPanelOverlay = null;
            return;
        }
        Region backdrop = new Region();
        backdrop.setStyle("-fx-background-color:rgba(0,0,0,0.55);");
        backdrop.setOnMouseClicked(e -> { parentStack.getChildren().remove(aiPanelOverlay); aiPanelOverlay = null; });
        VBox panel = new VBox(18);
        panel.setPrefWidth(420); panel.setMaxHeight(620); panel.setPadding(new Insets(28));
        panel.setStyle("-fx-background-color:" + BG_SURFACE + ";-fx-background-radius:20;-fx-border-color:" + ACCENT_PURPLE + "66;-fx-border-radius:20;-fx-border-width:1.5;");
        panel.setEffect(new DropShadow(40, Color.web(ACCENT_PURPLE, 0.35)));
        Label panelIcon  = new Label("◎"); panelIcon.setStyle("-fx-text-fill:" + ACCENT_PURPLE + ";-fx-font-size:26px;");
        Label panelTitle = new Label("AI Intelligence Engine"); panelTitle.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:17px;-fx-font-weight:bold;");
        Label panelSub   = new Label("Powered by Retail AI Analytics"); panelSub.setStyle("-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:12px;");
        HBox panelHeader = new HBox(14, panelIcon, new VBox(3, panelTitle, panelSub));
        panelHeader.setAlignment(Pos.CENTER_LEFT);
        Button closeBtn = new Button("✕");
        closeBtn.setStyle("-fx-background-color:transparent;-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:16px;-fx-cursor:hand;-fx-padding:4 8;-fx-background-radius:6;");
        closeBtn.setOnMouseEntered(e -> closeBtn.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:16px;-fx-cursor:hand;-fx-padding:4 8;-fx-background-radius:6;"));
        closeBtn.setOnMouseExited(e  -> closeBtn.setStyle("-fx-background-color:transparent;-fx-text-fill:" + TEXT_SECONDARY + ";-fx-font-size:16px;-fx-cursor:hand;-fx-padding:4 8;-fx-background-radius:6;"));
        closeBtn.setOnAction(e -> { parentStack.getChildren().remove(aiPanelOverlay); aiPanelOverlay = null; });
        Region closeSpacer = new Region(); HBox.setHgrow(closeSpacer, Priority.ALWAYS);
        HBox topRow = new HBox(panelHeader, closeSpacer, closeBtn); topRow.setAlignment(Pos.CENTER_LEFT);
        Separator panelSep = new Separator(); panelSep.setStyle("-fx-background-color:" + BORDER + ";");
        HBox thinkingRow = new HBox(8); thinkingRow.setAlignment(Pos.CENTER_LEFT);
        Label thinkLbl = new Label("Analysing business data"); thinkLbl.setStyle("-fx-text-fill:" + ACCENT_PURPLE + ";-fx-font-size:13px;");
        HBox dots = new HBox(5);
        for (int i = 0; i < 3; i++) {
            Circle dot = new Circle(4, Color.web(ACCENT_PURPLE));
            FadeTransition ft = new FadeTransition(Duration.millis(600), dot);
            ft.setFromValue(0.2); ft.setToValue(1.0); ft.setAutoReverse(true); ft.setCycleCount(Animation.INDEFINITE);
            ft.setDelay(Duration.millis(i * 200)); ft.play();
            dots.getChildren().add(dot);
        }
        thinkingRow.getChildren().addAll(thinkLbl, dots);
        ScrollPane outputScroll = new ScrollPane();
        outputScroll.setPrefHeight(360); outputScroll.setFitToWidth(true);
        outputScroll.setStyle("-fx-background:transparent;-fx-background-color:transparent;");
        outputScroll.setVisible(false);
        VBox outputBox = new VBox(14); outputBox.setPadding(new Insets(4));
        outputScroll.setContent(outputBox);
        panel.getChildren().addAll(topRow, panelSep, thinkingRow, outputScroll);
        StackPane overlay = new StackPane(backdrop);
        HBox panelRow = new HBox(panel); panelRow.setAlignment(Pos.CENTER_RIGHT);
        overlay.getChildren().add(panelRow);
        aiPanelOverlay = overlay;
        parentStack.getChildren().add(overlay);
        panel.setTranslateX(440);
        TranslateTransition slideIn = new TranslateTransition(Duration.millis(380), panel);
        slideIn.setToX(0); slideIn.setInterpolator(Interpolator.SPLINE(0.16, 1, 0.3, 1)); slideIn.play();
        new Thread(() -> {
            try { Thread.sleep(1800); } catch (InterruptedException ignored) {}
            try {
                Map<String, Double> rev      = service.getMonthlyRevenue();
                Map<String, Double> insights = service.getSalesPredictionInsights();
                List<ProductBean>   prods    = service.getAllProducts();
                Map<String, Integer> topSell = service.getTopSellingProducts();
                List<ProductBean>   lowStock = service.getLowStockProducts();
                double totalRevenue  = rev.values().stream().mapToDouble(Double::doubleValue).sum();
                double avgMonthly    = rev.isEmpty() ? 0 : totalRevenue / rev.size();
                double predicted     = insights.get("prediction");
                double growth        = insights.get("growth");
                double totalInvValue = prods.stream().mapToDouble(p -> p.getSellingPrice() * p.getStockQuantity()).sum();
                double avgMargin     = prods.stream().mapToDouble(p -> p.getSellingPrice() == 0 ? 0 :
                    (p.getSellingPrice() - p.getCostPrice()) / p.getSellingPrice() * 100).average().orElse(0);
                String topProduct    = topSell.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse("N/A");
                int    criticalCount = lowStock.size();
                List<AiSection> sections = new ArrayList<>();
                sections.add(new AiSection("REVENUE SUMMARY", ACCENT_CYAN, List.of(
                    "Total revenue (all months): ₹ " + String.format("%,.2f", totalRevenue),
                    "Average monthly revenue: ₹ " + String.format("%,.2f", avgMonthly),
                    "Predicted next month: ₹ " + String.format("%,.2f", predicted),
                    "Growth rate vs last month: " + String.format("%.2f", growth) + "%")));
                sections.add(new AiSection("INVENTORY STATUS", ACCENT_GREEN, List.of(
                    "Total products: " + prods.size(),
                    "Total inventory value: ₹ " + String.format("%,.2f", totalInvValue),
                    "Average profit margin: " + String.format("%.1f", avgMargin) + "%",
                    "Critical low-stock items: " + criticalCount)));
                sections.add(new AiSection("TOP PERFORMER", ACCENT_AMBER, List.of(
                    "Best-selling product: " + topProduct,
                    "Stock action: " + (criticalCount > 0 ? criticalCount + " item(s) need urgent restock" : "All items adequately stocked"))));
                String conclusion = growth > 10
                    ? "Strong positive growth detected. The business is in an expansion phase. Recommend increasing inventory investment and exploring new product lines."
                    : growth > 0 ? "Moderate growth. Business is stable. Focus on optimising margins for low-performing products and reinforcing top sellers."
                    : "Revenue trend is declining. Immediate strategic action required — consider discounting slow-moving stock, enhancing marketing, and reviewing pricing strategy.";
                sections.add(new AiSection("AI CONCLUSION", growth > 10 ? ACCENT_GREEN : growth > 0 ? ACCENT_CYAN : ACCENT_RED, List.of(conclusion)));
                Platform.runLater(() -> {
                    thinkingRow.setVisible(false); outputScroll.setVisible(true);
                    for (int i = 0; i < sections.size(); i++) {
                        AiSection sec = sections.get(i);
                        VBox secBox = buildAiSection(sec.title, sec.color, sec.lines);
                        secBox.setOpacity(0); outputBox.getChildren().add(secBox);
                        FadeTransition ft = new FadeTransition(Duration.millis(400), secBox);
                        ft.setToValue(1.0); ft.setDelay(Duration.millis(i * 320)); ft.play();
                    }
                });
            } catch (Exception ex) {
                ex.printStackTrace();
                Platform.runLater(() -> {
                    thinkingRow.setVisible(false);
                    Label err = new Label("⚠ Could not fetch analytics data."); err.setStyle("-fx-text-fill:" + ACCENT_RED + ";");
                    outputBox.getChildren().add(err); outputScroll.setVisible(true);
                });
            }
        }).start();
    }

    private VBox buildAiSection(String title, String color, List<String> lines) {
        Label titleLbl = new Label(title);
        titleLbl.setStyle("-fx-text-fill:" + color + ";-fx-font-size:11px;-fx-font-weight:bold;-fx-letter-spacing:1;");
        Region accentLine = new Region(); accentLine.setPrefHeight(1.5);
        accentLine.setStyle("-fx-background-color:linear-gradient(to right," + color + "88,transparent);");
        VBox linesBox = new VBox(6);
        for (String line : lines) {
            Label l = new Label("·  " + line);
            l.setStyle("-fx-text-fill:" + TEXT_PRIMARY + ";-fx-font-size:13px;-fx-wrap-text:true;");
            l.setWrapText(true); linesBox.getChildren().add(l);
        }
        VBox box = new VBox(8, titleLbl, accentLine, linesBox);
        box.setPadding(new Insets(14));
        box.setStyle("-fx-background-color:" + BG_ELEVATED + ";-fx-background-radius:12;-fx-border-color:" + color + "33;-fx-border-radius:12;-fx-border-width:1;");
        return box;
    }

    private static class AiSection {
        String title, color; List<String> lines;
        AiSection(String t, String c, List<String> l) { title=t; color=c; lines=l; }
    }

    // ─── Utility ─────────────────────────────────────────────────────────────

    private String compactNum(double v) {
        if (v >= 1_000_000) return String.format("%.1fM", v / 1_000_000);
        if (v >= 1_000)     return String.format("%.1fK", v / 1_000);
        return String.format("%.0f", v);
    }

    public static void main(String[] args) { launch(); }
}