package common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

public interface RetailService extends Remote {

    void addProduct(ProductBean product) throws RemoteException;

    List<ProductBean> getAllProducts() throws RemoteException;
    
    List<ProductBean> getLowStockProducts() throws RemoteException;

    void addSale(SalesBean sale) throws RemoteException;
    
    void deleteProduct(int productId) throws RemoteException;
    
    void updateProduct(ProductBean product) throws RemoteException;

    Map<String, Double> getSalesPredictionInsights() throws RemoteException;
    
    String login(String username, String password) throws RemoteException;

    Map<String, Double> getMonthlyRevenue() throws RemoteException;

    Map<String, Integer> getTopSellingProducts() throws RemoteException;
}